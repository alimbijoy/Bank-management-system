
<?php
   $url1=$_SERVER['REQUEST_URI'];
  header("Refresh: 2; URL=$url1");
?>




<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>



<?php 
  if(isset($_GET['customerId'])||$_GET['customerId']==NULL){
     $id = $_GET['customerId'];   
     $customerById = $customer->getCustomerById($id);   
}

?>
                 
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">

          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" > Customer Profile:</h2>
         
		<div class="row-fluid">

					<div class="box-content">
                                         
                                   

                                            <table border="2" class="table1" style="width:100%">
                                               
                                                

                                                
                                                <tr>
                                                  <th style="width:30%;  background: #DB0D15"> Customer Photo</th>
                                                 
                                                  <th rowspan="2" style="width:40%;">
                                                    <?php 
                                                    $stutas = $loan->stutas($id);
                                                    if($stutas){
                                                        while ($result = $stutas->fetch_assoc()){
                                                         
                                                            if($result['cuslevel'] ==0){?>
                                                           <button type="" name="" class="btn btn-danger">Panding</button>   
                                                      <?php  } else { ?>
                                                            <button type="" name="" class="btn btn-info">Paid</button>
                                                      <?php   }    }   }?>
                                                            
                                                            
                                                 
                                                  
                                                  
                                                   
                                                  </th>
                                                  <th colspan="2" style="width:40%;  background: #DB0D15">Nomoni photo</th>

                                                </tr>
                                                
                                                <tr>
                                         <?php 
                                          $getcusimg = $customer->getcusimg($id);
                                          if($getcusimg){
                                              while ($result = $getcusimg->fetch_assoc()){

                                         ?>

                                             <th style="width:30%;"><img style="border-radius: 5px; width: 250px; height: 300px" src="<?php echo $result['customerPhoto'];?>"</th>
                                          <?php } } ?>  
                                           <?php
                                             $getNomoni = $customer->getNomoniById($id);
                                             
                                             if($getNomoni){
                                                 while ($result = $getNomoni->fetch_assoc()){
                                             ?>    
                                            <th colspan="2" style="width:40%"><img style="border-radius: 5px; width: 250px; height: 300px" src="<?php echo $result['image'];?>"</th>
                                             <?php } } ?> 
              
                                                </tr>
                                                
                                        <?php 
                                        if($customerById){
                                            while($result = $customerById->fetch_assoc()){?>
                                                <tr>
                                                  
                                                    <td style="text-align: center;  background: #3A3A3A" colspan="3">
                                                       <a class="btn btn-primary" href="updateCustomer.php?customerId=<?php echo $result['customerId']; ?>">Update Customer</a>
                                                       <a class="btn btn-primary" href="addNomoni.php?customerId=<?php echo $result['customerId']; ?>">Add Nomoni</a>
                                                       <a class="btn btn-primary" href="editNomoni.php?customerId=<?php echo $result['customerId']; ?>">Edit Nomoni</a>
                                                       <a class="btn btn-primary" href="loan.php?customerId=<?php echo $result['customerId']; ?>">Add Loan</a>
                                                       <a class="btn btn-primary" href="edit_loan.php?customerId=<?php echo $result['customerId']; ?>">Update Loan</a>
                                                       <a onclick="return confirm('Are you sure to delete loan !')" class="btn btn-primary" href="deleteloan.php?customerId=<?php echo $result['customerId']; ?>">Delete Loan</a>
                                                       <a class="btn btn-primary" href="gnsonchoy_uttolon.php?customerId=<?php echo $result['customerId']; ?>">General saving lifed</a>
                                                       <a class="btn btn-primary" href="addsthayisonchoy.php?customerId=<?php echo $result['customerId']; ?>">Add perment saving </a>
                                                       <a class="btn btn-primary" href="STHSonchoy_uttolon.php?customerId=<?php echo $result['customerId']; ?>">Perment saving lifed</a>
                                                       <a class="btn btn-primary" href="addBima.php?customerId=<?php echo $result['customerId']; ?>">Add DPS </a>
                                                        <a onclick="return confirm('Are you sure to delete DPS !')" class="btn btn-primary" href="deletedps.php?deletedp=<?php echo $result['customerId']; ?>">Delete DPS</a>
                                                       <a class="btn btn-primary" href="bimaUttolon.php?customerId=<?php echo $result['customerId']; ?>">DPS lifed </a>
                                                       
                                                      
                                                       
                                                         
                                                           
                                                    </td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  
                                                    <td style="text-align: center;  background: #DB0D15" colspan="3">Customer information</td>
                                                  
                                                </tr>
                                                
                                                 <tr>
                                                  <td>Customer area</td>
                                                  <td colspan="2"><?php echo $result['customerArea']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Customer Id</td>
                                                  <td colspan="2"><?php echo $result['customerId']; ?></td>
                                                  
                                                </tr>
                                                <tr>
                                                  <td>Customer Name</td>
                                                  <td colspan="2"><?php echo $result['CustomerName']; ?></td>
                                                 
                                                </tr>
                                                
                                                  <tr>
                                                  <td>Father Name</td>
                                                  <td colspan="2"><?php echo $result['cusfatherName']; ?></td>
                                                 
                                                </tr>
                                                
                                                <tr>
                                                  <td>Mother Name</td>
                                                  <td colspan="2"><?php echo $result['cusmotherName']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Vallage</td>
                                                  <td colspan="2"><?php echo $result['cusvillage'] ; ?></td>
                                                 
                                                </tr>
                                                
                                                <tr>
                                                  <td>Post</td>
                                                  <td colspan="2"><?php echo $result['cuspost']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Thana</td>
                                                  <td colspan="2"><?php echo $result['custhana']; ?></td>
                                                  
                                                </tr>
                                                <tr>
                                                  <td>District</td>
                                                  <td colspan="2"><?php echo $result['cusDistrict']; ?></td>
                                                  
                                                </tr>
                                                <tr>
                                                  <td>Gender</td>
                                                  <td colspan="2"><?php echo $result['cusgender']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Nid or Birth Reg:</td>
                                                  <td colspan="2"><?php echo $result['cusnid']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Mobile Number</td>
                                                  <td colspan="2"><?php echo $result['cusmobileNumber']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Joining Date</td>
                                                  <td colspan="2"><?php echo $result['cusJoinDate']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Date Of Birth</td>
                                                  <td colspan="2"><?php echo $result['cusdateOfBirth']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Date By Computer</td>
                                                  <td colspan="2"><?php echo $result['date']; ?></td>
                                                  
                                                </tr>
                                              <?php } } ?>    
                                                 <tr>

                                                     <td colspan="3" style="text-align: center;  background: #46B82F">Nomoni information</td>
                                                    
                                                </tr>
                                            
                                          <?php
                                             $getNomoni = $customer->getNomoniById($id);
                                             
                                             if($getNomoni){
                                                 while ($result = $getNomoni->fetch_assoc()){
                         
                                             ?>     
                                                
                                                <tr>
                                                  <td>Name</td>
                                                  <td colspan="2"><?php echo $result['nomoniName']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Father Name</td>
                                                  <td colspan="2"><?php echo $result['fatherName']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Mother Name</td>
                                                  <td colspan="2"><?php echo $result['motherName']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Village</td>
                                                  <td colspan="2"><?php echo $result['village']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Relation Of Customer</td>
                                                  <td colspan="2"><?php echo $result['nomorelation']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Age fo Nomoni</td>
                                                  <td colspan="2"><?php echo $result['age']; ?></td>
                                                  
                                                </tr>
                                             <?php } } ?> 
                                                
                                                  <tr>
                                                
                                                      <td colspan="3" style="text-align: center;  background: #46B82F">Loan information</td>
                                                    
                                                </tr>
                                                
                                               <?php 
                                                 $getaday = $loan->getadayById($id);
                                                    
                                                   if($getaday){
                                                     
                                                    while($row = $getaday->fetch_assoc()){
                                                     $result  = $row['sum(kistiaday)'];
                                                    $inTotall = Session::get("inTotall");
                                                    $sthity = $inTotall - $result;
                                                  ?> 
                                                
                                      
                                                <tr>
                                                  <td>Total Paid</td>
                                                  <td colspan="2"><?php echo $result; ?>  Taka </td>
                                                  
                                                </tr>
                                                
                                                
                                                <tr>
                                                  <td>Status</td>
                                                  <td colspan="2"><?php echo $sthity; ?>  Taka </td>
                                                  
                                                </tr>
                                           <?php } } ?> 
                                           
                                          <?php 
                                         $getintotalamo = $loan->getintotalamo($id);
                                                    
                                            if($getintotalamo){

                                            while($row = $getintotalamo->fetch_assoc()){
                                            $inTotall = $row['sum(inTotal)'];
                                             Session::set('inTotall', $inTotall);
                                            }
                                           }
                                          ?>      
                                                
                                                

                                                
                                            <?php 
                                                 $getnumber = $loan->getnumberkisti($id);
                                                    
                                                   if($getnumber){
                                                     
                                                   $count = mysqli_num_rows($getnumber);

                                               ?>        
                                                
                                                 <tr>
                                                  <td>Payment Number </td>
                                                  <td colspan="2">( <?php echo $count; ?> ) </td>                                               
                                                </tr>
                                                
                                             <?php }  ?>       
                                                        
                                                
                                                
                                             
                                                
                                              <?php 
                                               $getLoanById = $loan->getLoanById($id);
                                               if($getLoanById){
                                                   while ($result = $getLoanById->fetch_assoc()){
                                                  
                                               ?> 
                                                
                                               <tr>
                                                  <td>Type Of Loan</td>
                                                  <td colspan="2"><?php echo $result['loanType']; ?></td>
                                                  
                                                </tr>
                                                
                                                 <tr>
                                                  <td>Loan Amount</td>
                                                  <td colspan="2"><?php echo $result['amount']; ?></td>
                                                  
                                                </tr>
                                                
                                                  <tr>
                                                  <td>Profit</td>
                                                  <td colspan="2"><?php echo $result['munafa']; ?></td>
                                                  
                                                </tr>
                                                
                                                
                                         
                                                <tr>
                                                  <td>In Total</td>
                                                  <td colspan="2"><?php echo $result['inTotal']; ?>  Taka </td>
                                                  
                                                </tr>
                                                

                                                <tr>
                                                  <td>Number of loan</td>
                                                  <td colspan="2">( <?php echo $result['loanNumbber']; ?> )</td>
                                                  
                                                </tr>
 
                                                
                                                 <tr>
                                                  <td>Payment of loan</td>
                                                  <td colspan="2"><?php echo $result['kisti']; ?></td>
                                                  
                                                </tr>
                                                
                                                 <tr>
                                                  <td>Total payment of loan</td>
                                                  <td colspan="2"><?php echo $result['totalKisti']; ?></td>
                                                  
                                                </tr>
                                                
                                                 <tr>
                                                  <td> Loan Bima</td>
                                                  <td colspan="2"><?php echo $result['loanBima']; ?> Taka</td>
                                                  
                                                </tr>
                                                <tr>
                                                  <td>Date of loan delivary</td>
                                                  <td colspan="2"><?php echo $result['startDate']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Date of loan end</td>
                                                  <td colspan="2"><?php echo $result['endDate']; ?></td>
                                                  
                                                </tr> 
                                                
                                                
                                                 <tr>
                                                  <td>Granted Name</td>
                                                  <td colspan="2"><?php echo $result['grantedName']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Granted mobile number</td>
                                                  <td colspan="2"><?php echo $result['grantedMobile']; ?></td>
                                                  
                                                </tr>
                                                
                                                 <tr>
                                                  <td>Relation with customer</td>
                                                  <td colspan="2"><?php echo $result['relation']; ?> //<a style="color:#DB0D15;" href="kistiMore.php?customerId=<?php echo $result['customerId']; ?>"> More</a> </td>
                                                 <?php  Session::set('customerId', $result['customerId']); ?>
                                                </tr>
                                              <?php } } ?>
        
                                              
                                                
                                      <?php include 'inc/general_saving.php'; ?>
                                      <?php include 'inc/perment_saving.php'; ?>                                                
                                      <?php include 'inc/dps.php'; ?>             
                                        
                                              </table> 
                                             <a style="float: right; color:#DB0D15; background: #FFCE44; padding: 3px; border-radius: 2px; font-size: 20px; margin-top: 20px; margin-right: 50%" href="search.php?customerId=<?php echo Session::get("customerId"); ?>"> Print</a>                               


					</div>


				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>