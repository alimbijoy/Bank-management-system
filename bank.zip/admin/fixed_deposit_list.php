<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if(isset($_GET['delete'])){
    $id = $_GET['delete'];
    $fixdepositdelte = $fixedDeposit->fixdepositdelte($id);
}

?>
          
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #FF9800; padding: 10px; border-radius: 4px;" >Fixed deposit customer list:</h2>
         
		<div class="row-fluid">
			
					<div class="box-content">
                                           
                                          
                                            
                                           <table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Customer Name</th>
								  <th>Joining Date</th>
								  <th>Amount</th>
                                                                  <th>পরিমান কথায়</th>
                                                                  <th>Mobile</th>
								  <th>Customer Id</th>
								  <th>Actions</th>
							  </tr>
						  </thead> 
                                                  
                                           <?php
                                             $getFixedDepositCustomer = $fixedDeposit->getFixedDepositCustomer();
                                             if($getFixedDepositCustomer){
                                                 while($result = $getFixedDepositCustomer->fetch_assoc()){
                                                $id = $result['id'];
                                            ?>   
                                                  
                                                  
						  <tbody>
							<tr>
                                                                
								<td class="center"><?php echo $result['CustomerName']; ?></td>
                                                                <td class="center"><?php echo $result['cusJoinDate']; ?></td>
								<td class="center"><?php echo $result['amount']; ?></td>
                                                                <td class="center"><?php echo $result['amountkothay']; ?></td>
                                                                <td class="center"><?php echo $result['cusmobileNumber']; ?></td>
                                                                <td class="center"><?php echo $result['id']; ?></td>
                                                                
								
								<td class="center">
                                                                    <a class="btn btn-success" href="fixed_deposit_profile.php?viewdeposit=<?php echo $result['id']; ?>">
										<i class="halflings-icon white zoom-in"></i> 
      
									</a>
                                                                    
									<a class="btn btn-info" href="fixed_deposit_edit.php?editdepsit=<?php echo $result['id']; ?>">
										<i class="halflings-icon white edit"></i>  
									</a>
									<a onclick="return confirm('Are you sure to Delete !')" class="btn btn-danger" href="?delete=<?php echo $result['id']; ?>">
										<i class="halflings-icon white trash"></i> 
									</a>
                         
								</td>
							</tr>
							
						  </tbody>
                                                  
                                             <?php } } ?>       
                                                  
					  </table>
                                            

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>