<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if(isset($_GET['customerId'])){
    $customerId = $_GET['customerId'];

}
?>


<?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])) {

        $addloan = $loan->addLoan($_POST,$customerId);
    }

 ?>

                 
                        
			<!-- start: Content -->
          <div id="content" class="span10" style="background-color: #4B15BE" >			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Loan Sheet:</h2>
           <?php 
            if(isset($addloan)){
                echo $addloan;
            }
            ?>
		<div class="row-fluid">
			
					<div class="box-content" >
                                            
                                           
                                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data" style="background-color: #2D89EF">
						  <fieldset>
                                                      
                                                      
                                                     <div class="control-group">                                   
							  <label class="control-label" for="typeahead"></label>
							  <div class="controls"                                                 
								<p class="help-block"></p>							  
							  </div>
                                                     </div>    
                                                
                                                    <div class="control-group">
                                                      <label class="control-label" for="selectError3">Type of loan</label>
                                                      <div class="controls">
                                                          <select name="loanType" id="selectError3">
                                                              <option>Select</option>
                                                              <option value="DailySortTime">Daily Sort Time</option>
                                                              <option value="DailyLongTime">Daily Long Time</option>
                                                              <option value="Weekly">Weekly</option>
                                                              <option value="Monthly">Monthly</option>
                                                            

                                                        </select>
                                                      </div>
                                                   </div>     
                                                      
                                                      
                                                      
                                                      
                                                      
						  <div class="control-group">
                                                         
							  <label class="control-label" for="typeahead">Amount</label>
							  <div class="controls">
                                                              <input type="text" name="amount" class="span3 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> Loan Number
                                                              <input type="text" name="loanNumbber" class="span3 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 

								<p class="help-block"></p>
							  
							  </div>
                                                     </div>    
                                            
                                                          
                                                          

							<div class="control-group">
							  <label class="control-label" for="typeahead">Munafa</label>
							  <div class="controls">
                                                              <input type="text" name="munafa" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                      
                                                      
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">In Total</label>
							  <div class="controls">
                                                              <input type="text" name="inTotal" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Date</label>
							  <div class="controls">
                                                              <input type="text" name="startDate" >To 
                                                              <input type="text" name="endDate" > 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                               
                                                          
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Kisti Amount</label>
							  <div class="controls">
                                                              <input type="text" name="kisti" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                        <div class="control-group">
							  <label class="control-label" for="typeahead">Total kisti</label>
							  <div class="controls">
                                                              <input type="text" name="totalKisti" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Loan Bima</label>
							  <div class="controls">
                                                              <input type="text" name="loanBima" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                        <div class="control-group">
							  <label class="control-label" for="typeahead">Granted Name</label>
							  <div class="controls">
                                                              <input type="text" name="grantedName" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Granted Mobile Number</label>
							  <div class="controls">
                                                              <input type="text" name="grantedMobile" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          <div class="control-group">
							  <label class="control-label" for="typeahead">Relation</label>
							  <div class="controls">
                                                              <input type="text" name="relation" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
       
							
							<div class="form-actions">
                                                            <button type="submit" name="submit" class="btn btn-primary">Confirm</button>
							  <button type="reset" class="btn">Cancel</button>
							</div>
						  </fieldset>
						</form>   

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>