<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>



<?php 
  if(isset($_GET['deletedp'])||$_GET['deletedp']==NULL){
     $iddeletedp = $_GET['deletedp'];   
      $customer->deletedps($iddeletedp); 
}
?>


			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">
    <h1 style="color: #FE2E2B">DPS delete successfully!</h1>
     <a class="btn btn-primary" href="customer_list.php">Back to customers list </a>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>