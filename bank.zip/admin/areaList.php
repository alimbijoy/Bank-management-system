<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if(isset($_GET['areaId'])){
    $id = $_GET['areaId'];
    $delArea = $customer->delUser($id);
    
}

?>
          
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Area List:</h2>
         
		<div class="row-fluid">
			
					<div class="box-content">
                                           
                                          
                                            
                                           <table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Name</th>
								  
							  </tr>
						  </thead> 
                                                  
                                           <?php
                                             $getAllArea = $customer->getAllArea();
                                             if($getAllArea ){
                                                 while($result = $getAllArea->fetch_assoc()){
                                        
                                            ?>   
                                                  
                                                  
						  <tbody>
							<tr>
                                                            <td><?php echo $result['areaName']; ?></td>
								
							
								<td class="center">
                                                                    <a class="btn btn-success" href="viewArea.php?areaId=<?php echo $result['areaId']; ?>">
										<i class="halflings-icon white zoom-in"></i>  
									</a>
									<a class="btn btn-info" href="viewArea.php?areaId=<?php echo $result['areaId']; ?>">
										<i class="halflings-icon white edit"></i>  
									</a>
									<a onclick="return confirm('Are you sure to Delete !')" class="btn btn-danger" href="?areaId=<?php echo $result['areaId']; ?>">
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
							
						  </tbody>
                                                  
                                             <?php } } ?>       
                                                  
					  </table>
                                            

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>