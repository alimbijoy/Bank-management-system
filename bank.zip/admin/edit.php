<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>


<?php
 if(isset($_GET['editUser'])){
    $id = $_GET['editUser'];
}

?>



<?php

    if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit'])) {

        $updateUser = $usr->updateUser($_POST, $_FILES, $id);
    }

 ?>


                 
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Edit User:</h2>
           <?php 
            if(isset($updateUser)){
                echo $updateUser;
            }
            ?>
		<div class="row-fluid">
			
					<div class="box-content">
                                            
                                           
                                            <form class="form-horizontal" action="" method="POST" enctype="multipart/form-data" style="background-color: #2D89EF">
						  <fieldset>
                                                      
                                                     <?php
                                                    
                                                        $selectAllUser = $usr->selectAllUser($id);
                                                        if($selectAllUser){
                                                            while($result = $selectAllUser->fetch_assoc()){

                                                       ?> 
                                                      
                                                     <div class="control-group">                                   
							  <label class="control-label" for="typeahead"></label>
                                                          <img width="100px" height="100px" style="margin-top:10px"  src="<?php echo $result['image']; ?>" />
							  <div class="controls" 
                                                                
								<p class="help-block"></p>							  
							  </div>
                                                     </div> 
                                                    
                    
                                                     
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead">User name </label>
							  <div class="controls">
                                                              <input type="text" name="userName" value="<?php echo $result['userName']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
                                                       </div>
                                                      
							<div class="control-group">
							  <label class="control-label" for="typeahead">Name</label>
							  <div class="controls">
                                                              <input type="text" name="adminName" value="<?php echo $result['adminName']; ?>"  class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                         <div class="control-group">
							  <label class="control-label" for="typeahead">Mobile Number</label>
							  <div class="controls">
                                                              <input type="number" name="mobile" value="<?php echo $result['mobile']; ?>" class="span6 typeahead" id="typeahead"  data-provide="typeahead" data-items="4"> 
								<p class="help-block"></p>
							  </div>
							</div>
                                                          
                                                          
                                                          

						
                               
                                                          
                                                         <div class="control-group">
								<label class="control-label" for="selectError3">Select User Role</label>
								<div class="controls">
                                                                    <select name="adminRole" id="selectError3">
                                                                        <?php
                                                                        if($result['adminRole']==1){?>
                                                                       
                                                                         <option value="1" selected>Admin</option>  
                                                                         <option value="2">Editor</option>               
                                                                         <option value="3">Author</option>  
                                                                      <?php }elseif ($result['adminRole']==2) {?>
                                                                        
                                                                         <option value="1">Admin</option>  
                                                                         <option value="2" selected>Editor</option>               
                                                                         <option value="3">Author</option>        
                                                                       <?php   } else {?>
                                                                                                 
                                                                         <option value="1">Admin</option>  
                                                                         <option value="2">Editor</option>               
                                                                         <option value="3" selected>Author</option>                                                         
                                                                        <?php }?>
                                                                        
                                                                                   
								  </select>
								</div>
							  </div> 
                                                          
                                                          

                                                        <div class="control-group">
                                                             
                                                            <label class="control-label" for="fileInput">photo (PP Size)</label> 
                                                            <div class="controls">
                                                                <input name="image" class="input-file uniform_on" id="fileInput" type="file"> 
                                                            </div>
                                                           
							</div>
        
							
							<div class="form-actions">
                                                            <button type="submit" name="submit" class="btn btn-primary">Update User</button>
                                                           							</div>
                                                        <?php } } ?>    
						  </fieldset>
						</form>   

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>