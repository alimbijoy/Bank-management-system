<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>


<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Edit Nomoni:</h2>
          
<div class="row-fluid">
			
            <div class="box-content">
                
               
                
                
                
                
             
                <table class="mytable">
                    <tr>
                        <td>
                            <h2> Kisti Aday</h2>
                            <form action="" method="">
                               Kisti Aday <input type="text" name=""/>
                                <input type="submit" name="submit" value="Submit"/>
                                
                            </form>
                        </td>
                     
                        
                    </tr>
                    
                      
                </table>
                
                   
                
                


            </div>









				
				
</div>

</div><!--/.fluid-container-->





<?php include'inc/footer.php'; ?><?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

