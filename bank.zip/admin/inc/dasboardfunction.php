

  <?php 
    $getTotal = $loan->getTotal();
    if($getTotal){
        while ($row = $getTotal->fetch_assoc()){
         $getTotall = $row['sum(amount)'];
          Session::set('getTotall', $getTotall);

        }
    }
    
     $getTotalAday = $loan->getTotalAday();
      if($getTotalAday){
        while ($rows = $getTotalAday->fetch_assoc()){
         $getTotallAday = $rows['sum(kistiaday)'];
          Session::set('getTotallAday', $getTotallAday);
          
           
        }
    }
    
    
  

    ?>




<?php 
 $totalfrofitt = Session::get("getTotalProfit");
 $total = Session::get("getTotall");
 $totaladay = Session::get("getTotallAday");
 $reamainin = $total - $totaladay + $totalfrofitt;
 Session::set('reamainin', $reamainin);
 
?>


<?php

$getGNsonchoy = $loan->getGNsonchoy();
      if($getGNsonchoy){
        while ($rows = $getGNsonchoy->fetch_assoc()){
         $getGNtotal = $rows['sum(gnsonchoyaday)'];
          Session::set('getGNtotal', $getGNtotal);
          
           
        }
    }
      $getGNsonchoyUttolon = $loan->getGNsonchoyUttolon();
      if($getGNsonchoyUttolon){
        while ($rows = $getGNsonchoyUttolon->fetch_assoc()){
         $getGNuttolon = $rows['sum(gnuttolon)'];
          Session::set('getGNuttolon', $getGNuttolon);
          
          
          $getGNtotal = Session::get("getGNtotal");
          $gnTotal = $getGNtotal- $getGNuttolon;
          Session::set('gnTotal', $gnTotal);
        }
    } 
   
     $getSthayisonchoy = $loan->getSthayisonchoyy();
      if($getSthayisonchoy){
        while ($rows = $getSthayisonchoy->fetch_assoc()){
         $getSthayiSonchoy = $rows['sum(sthayiaday)'];
          Session::set('getSthayiSonchoy', $getSthayiSonchoy);

        }
    } 
    
  
     $getSthayisonchoyUttolon = $loan->getSthayisonchoyUttolon();
      if($getSthayisonchoyUttolon){
        while ($rows = $getSthayisonchoyUttolon->fetch_assoc()){
         $sthayiSonchoyUttolon = $rows['sum(sthuttolon)'];
          Session::set('sthayiSonchoyUttolon', $sthayiSonchoyUttolon);

        }
    } 

    $sthayisoncho = Session::get("getSthayiSonchoy");
    $sthutto = Session::get("sthayiSonchoyUttolon");
    $sthconchoySthiti = $sthayisoncho- $sthutto;
    Session::set('sthconchoySthiti', $sthconchoySthiti);
   
 ?>

<?php
    $getBima = $loan->getBimaAll();
    if($getBima){
     while ($rows = $getBima->fetch_assoc()){
     $getAllBima = $rows['sum(monthlyAday)'];
     Session::set('getAllBima', $getAllBima);

      }
  } 
  
   $getBimaUttolonAll = $loan->getBimaUttolonAll();
    if($getBimaUttolonAll){
     while ($rows = $getBimaUttolonAll->fetch_assoc()){
     $getAllBimaUttolon = $rows['sum(bimaUttolon)'];
     Session::set('getAllBimaUttolon', $getAllBimaUttolon);

      }
  } 

  $bimasthyti = $getAllBima - $getAllBimaUttolon;
  Session::set('bimasthyti', $bimasthyti);
?>



<?php 
 //dps total one month
    $getdpsonemonth = $loan->getdpsonemonth();
    if($getdpsonemonth){
        while ($row = $getdpsonemonth->fetch_assoc()){
         $getdpsone = $row['sum(bimaAday)'];
          Session::set('getdpsone', $getdpsone);

        }
    }

?>







<?php
//    Customer
    
    $getDailyCustomer = $loan->getDailyCustomer();
    if($getDailyCustomer){
                                         
        $daily = mysqli_num_rows($getDailyCustomer);
        Session::set('daily', $daily);
         
    }
    
     $getDailyLongTimeCus = $loan->getDailyLongTimeCus();
    if($getDailyLongTimeCus){
                                         
        $dailyLongTimecusto = mysqli_num_rows($getDailyLongTimeCus);
        Session::set('dailyLongTimecusto', $dailyLongTimecusto);
         
    }
      
      
     $getweeklyCustomer = $loan->getweeklyCustomer(); 
      if($getweeklyCustomer){
                                         
        $weekly = mysqli_num_rows($getweeklyCustomer);
        Session::set('weekly', $weekly);
      }
    
     $getMontlyCustomer = $loan->getMontlyCustomer();
      if($getMontlyCustomer){
                                         
        $monthly = mysqli_num_rows($getMontlyCustomer);
        Session::set('monthly', $monthly);
      }
      
      
       $getTotalCustomer = $loan->getTotalCustomer();
      if($getTotalCustomer){
                                         
        $total = mysqli_num_rows($getTotalCustomer);
        Session::set('total', $total);
      }
      
      
       $getTotalBimaCustomer = $loan->getTotalBimaCustomer();
      if($getTotalBimaCustomer){
                                         
        $totalBima = mysqli_num_rows($getTotalBimaCustomer);
        Session::set('totalBima', $totalBima);
      }
      
      
      
        $generaleSavingCustomer = $loan->generaleSavingCustomer();
      if($generaleSavingCustomer){
                                         
        $gnsaving = mysqli_num_rows($generaleSavingCustomer);
        Session::set('gnsaving', $gnsaving);
      }
      
      
      $permentSavingCustomer = $loan->permentSavingCustomer();
      if($permentSavingCustomer){
                                         
        $permentsaving = mysqli_num_rows($permentSavingCustomer);
        Session::set('permentsaving', $permentsaving);
      }
      
      
     //    Customer 


?>







<?php


     $getProfit = $loan->getProfit();
      if($getProfit){
        while ($rows = $getProfit->fetch_assoc()){
         $getTotalProfit = $rows['sum(munafa)'];
          Session::set('getTotalProfit', $getTotalProfit);
  
     
    }
  }
   $getSortDailyProfit = $profit->getSortDailyProfit();
       if($getSortDailyProfit){
       while ($row = $getSortDailyProfit->fetch_assoc()){      
       $getSDProfit = $row['sum(kistiaday)'];     
       $sdprofitdh = $getSDProfit/100;
       $sdprofit   = $sdprofitdh *10;
       
       $onepersent = $sdprofit / 100;
       $one = $onepersent * 9.09090909090909;
       
       $sdnetprofit = $sdprofit - $one;
      Session::set('sdnetprofit', $sdnetprofit); 

      }
     }
     
       $getLongDailyProfit = $profit->getLongDailyProfit();
       if($getLongDailyProfit){
       while ($row = $getLongDailyProfit->fetch_assoc()){      
       $getLDProfit = $row['sum(kistiaday)'];     
       $ldprofitdh = $getLDProfit/100;
       $ldprofit   = $ldprofitdh *15; 
       
       $twopersent = $ldprofit / 100;
       $twpersent  = $twopersent * 13.043478260869565217391304347826;
       $longnetpersent = $ldprofit - $twpersent;
       Session::set('longnetpersent', $longnetpersent);
      }
     }
     
     
       $getweeklyProfit = $profit->getweeklyProfit();
      if($getweeklyProfit){
      while ($row = $getweeklyProfit->fetch_assoc()){     
      $getWProfit = $row['sum(kistiaday)'];    
      $wprofitdh = $getWProfit/100;
      $wprofit   = $wprofitdh * 15; 
      
      $weeklypersent = $wprofit / 100;
      $wkpersent = $weeklypersent * 13.043478260869565217391304347826;
      
       $wknetpersent = $wprofit - $wkpersent;       
      Session::set('wknetpersent', $wknetpersent);
       

       }
      }
          
    $getMonthlyProfit = $profit->getMonthlyProfit();
    if($getMonthlyProfit){
    while ($row = $getMonthlyProfit->fetch_assoc()){      
    $getMProfit = $row['sum(kistiaday)'];
     $mprofitdh = $getMProfit/100;
     $mprofitt   = $mprofitdh * 15;
     
     $monthlypersent = $mprofitt / 100;
     $mpersent = $monthlypersent * 13.043478260869565217391304347826;
     $mnetpersent = $mprofitt - $mpersent;
    Session::set('mnetpersent', $mnetpersent);    
          
          
          
    }
 }

 
 $persent = $sdnetprofit+$longnetpersent+$wknetpersent+$mnetpersent;
 $profitSthiti = $getTotalProfit- $persent;
 Session::set('persent', $persent);
 Session::set('profitSthiti', $profitSthiti); 
    



?>



<?php

$getrinbima = $loan->getrinbima();
if($getrinbima){
    while ($row = $getrinbima->fetch_assoc()){
        $loanBima= $row['sum(rinBima)'];
      Session::set('loanBima', $loanBima);   
        
    }
}

$rinbimaUttolon = $profit->rinbimaUttolon();
if($rinbimaUttolon){
    while ($row = $rinbimaUttolon->fetch_assoc()){
      $rinbimautto= $row['sum(uttolon)'];
      Session::set('rinbimautto', $rinbimautto);   
     $totalRinbima  = Session::get("loanBima");
     $rinbimasthyty = $totalRinbima - $rinbimautto;
      Session::set('rinbimasthyty', $rinbimasthyty);
    }
}



?>

<?php 
$totalcost = $profit->totalcost();
if($totalcost){
    while ($row = $totalcost->fetch_assoc()){
        $cost= $row['sum(cost)'];
      Session::set('cost', $cost);   
        
    }
}
?>

<?php 
$totalbalnce = $profit->totalbalnce();
if($totalbalnce){
    while ($row = $totalbalnce->fetch_assoc()){
        $balnce= $row['sum(balance)'];
      Session::set('balnce', $balnce);   
        
    }
}

$balnceuttolonn = $profit->balnceuttolonn();
if($balnceuttolonn){
    while ($row = $balnceuttolonn->fetch_assoc()){
        $balncuttolo= $row['sum(uttolon)'];
        Session::set('balncuttolo', $balncuttolo);  
        $totalbalnces  = Session::get("balnce");
        $balncesthity = $totalbalnces - $balncuttolo;
         Session::set('balncesthity', $balncesthity); 
        
    }
}

?>

