



<?php

 include'../lib/Session.php';
 Session::checkSession();
 include'../helpers/Format.php';
spl_autoload_register(function($class){
  include "../classes/".$class.".php";
});

 ?>

<?php
  //set headers to NOT cache a page
  header("Cache-Control: no-cache, must-revalidate"); //HTTP 1.1
  header("Pragma: no-cache"); //HTTP 1.0
  header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
  // Date in the past
  //or, if you DO want a file to cache, use:
  header("Cache-Control: max-age=2592000"); 
//30days (60sec * 60min * 24hours * 30days)
?>


<?php
$fm = new Format();
$usr = new Userrole();
$customer = new Customer();
$loan = new Loan();
$fixedDeposit = new FixedDeposit();
$srce = new Search();
$profit = new Profit();
$dateMonth = new DadeMonthCount();

$front = new FrontEnd();

?>






<!DOCTYPE html>
<html lang="bn">
<head>

	<!-- start: Meta -->
	<meta charset="utf-8">
	<title>Mirco Credit</title>
	<meta name="description" content="Bootstrap Metro Dashboard">
	<meta name="author" content="Dennis Ji">
	<meta name="keyword" content="Metro, Metro UI, Dashboard, Bootstrap, Admin, Template, Theme, Responsive, Fluid, Retina">
	<!-- end: Meta -->

	<!-- start: Mobile Specific -->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<!-- end: Mobile Specific -->

	<!-- start: CSS -->
	<link id="bootstrap-style" href="css/bootstrap.min.css" rel="stylesheet">
	<link href="css/bootstrap-responsive.min.css" rel="stylesheet">
	<link id="base-style" href="css/style.css" rel="stylesheet">
	<link id="base-style-responsive" href="css/style-responsive.css" rel="stylesheet">
	<link href='http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800&subset=latin,cyrillic-ext,latin-ext' rel='stylesheet' type='text/css'>
	<!-- end: CSS -->


	<!-- The HTML5 shim, for IE6-8 support of HTML5 elements -->
	<!--[if lt IE 9]>
	  	<script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
		<link id="ie-style" href="css/ie.css" rel="stylesheet">
	<![endif]-->

	<!--[if IE 9]>
		<link id="ie9style" href="css/ie9.css" rel="stylesheet">
	<![endif]-->

	<!-- start: Favicon -->
	<link rel="shortcut icon" href="img/favicon.ico">
	<!-- end: Favicon -->
<style>

.table1{width:100%;border:1px solid #ddd;}
.table1 td{padding:5px 10px;text-align:left;}

table.table1 tr:nth-child(2n+1){background:#fff;height:30px;}
table.table1 tr:nth-child(2n){background:#fdf0f1;height:30px;}

 .userimg img{
           float: right;
        }
  .sidebarmenu a:hover{background: #E21E27}
  .mytable{border: 2px solid #000;}
  .mytable td{ border: 1px solid #000;}
  .mytable td, tr, select, input[type=text], input[type=submit]{padding: 5px;margin: 10px}
  .mytable h2{background: #19A15F; padding: 5px; text-align: center; border-radius: 4px;}

</style>




</head>

<body>
		<!-- start: Header -->
	<div class="navbar">
		<div class="navbar-inner">
			<div class="container-fluid">
				<a class="btn btn-navbar" data-toggle="collapse" data-target=".top-nav.nav-collapse,.sidebar-nav.nav-collapse">
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
					<span class="icon-bar"></span>
				</a>
                                                     
                            <div style="font-size: 16px; height: 45px; text-align: center; color: #FCC900; background: #E21E27;"><span>
                                    <div style="float:left; width: 5%; "><img style="width:100px; height: 100px; margin-left: -60px " src="upload/logoo.jpg"></div>     
                                    <div style="float:right; width: 95%">
                                     <?php
                                      $addtitlelist = $front->addtitlelist();
                                        if($addtitlelist){
                                        while($result = $addtitlelist->fetch_assoc()){
                                    ?>
                                    <marquee  style="margin-top: 12px"><?php echo $result['title']; ?></marquee>
                                        
                                    
                                    <?php } } ?> 
                                </span>
                                </div>
                            </div>

				<!-- start: Header Menu -->
				<div class="nav-no-collapse header-nav">
					<ul class="nav pull-right">




						<!-- start: User Dropdown -->
						<li class="dropdown">
							<a class="btn dropdown-toggle" data-toggle="dropdown" href="#">

								Wellcome:: <?php echo Session::get("adminName"); ?>
								<span class="caret"></span>
							</a>
							<ul class="dropdown-menu">
								<li class="dropdown-menu-title">
 									<span>Account Settings</span>
								</li>
								<li><a href="profile.php?adminId=<?php echo Session::get("adminId"); ?>"><i class="halflings-icon user"></i> Profile</a></li>
                                                                 <?php
                                                                        if (isset($_GET['action']) && $_GET['action'] == "logout") {
                                                                          Session::destroy();
                                                                        }
                                                                     ?>

								<li><a href="?action=logout"><i class="halflings-icon off"></i> Logout</a></li>
							</ul>
						</li>
						<!-- end: User Dropdown -->
					</ul>
				</div>
				<!-- end: Header Menu -->

			</div>
		</div>
	</div>
