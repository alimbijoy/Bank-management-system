                                                
                                                
                                               <tr>
                                                  
                                                    <td style="text-align: center; background: #DB0D15" colspan="3">Perment saving</td>
                                                  
                                                </tr>
                                                
                                                <?php 
                                                   $getsthaison = $loan->getstahisonchoy($id);
                                                   if($getsthaison){
                                                    while($row = $getsthaison->fetch_assoc()){
                                                     
                                                     $sthayiaday  = $row['sum(sthayiaday)']; 
                                                     $sthutto = Session::get("sthuttolon");
                                                     $utttolon = $sthayiaday - $sthutto;
                                                     
                                                ?>
                                            
                                                 <tr>
                                                  <td>Current balance and profit</td>
                                                  <td colspan="2"><?php echo $utttolon; ?> Taka || 
                                                  <?php 
                                                  
                                                  $getpsavingpayment = $loan->getpsavingpayment($id);
                                                   if($getpsavingpayment){
                                                       $row       = $getpsavingpayment->fetch_assoc();
                                                      $psavingg = $row['sthayiaday'];
                                                  }
                                                  if(isset($psavingg)){
                                                   $psavingcount = Session::get("count");
                                                   $compoundintotalpermentsaving = $dateMonth->compoundintotalpermentsaving($psavingg, $psavingcount);
                                                   $psprofit = $compoundintotalpermentsaving-$sthayiaday; 
                                                   echo round($psprofit); 
                                                  
                                                  } 
//                                                  if(isset($psprofit)){
//                                                  $getpsavingprofit = $loan->getpsavingprofit($id);
//                                                  if(empty($getpsavingprofit)){
//                                                    $psrofitinsert = $loan->psrofitinsert($id, $psprofit);
////                                                    echo $psrofitinsert;
//                                                  } else {
//                                                     $psrofitupdate = $loan->psrofitupdate($id, $psprofit);
////                                                     echo $psrofitupdate;
//                                                  }
//                                                  } 
                                                  ?>
                                                  </td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Total lifted</td>
                                                  <td colspan="2"><?php echo $sthutto; ?> Taka  // <a style="color:#DB0D15;" href="stuttolon.php?customerId=<?php echo Session::get("customerId"); ?>"> More</a></td>
                                                  
                                                </tr>
                                                
                                                 <tr>
                                                  <td>Intotal with lifted</td>
                                                  <td colspan="2"><?php echo $sthayiaday; ?> Taka</td>
                                                  
                                                </tr>
                                                
                                             <?php } } ?>
                                              
                                        <?php 
                                        $getSTHsonchoy = $loan->getSTHsonchoy($id);
                                         if($getSTHsonchoy){
                                         while($row = $getSTHsonchoy->fetch_assoc()){
                                         $sthuttolon  = $row['sum(sthuttolon)'];
                                         Session::set('sthuttolon', $sthuttolon);
                                         }
                                        } 
                                        ?>
                                                
                                                
                                                
                                                
                                             <?php 
                                                 $getnumber = $loan->getsthayisonchoykisti($id);
                                                    
                                                   if($getnumber){
                                                   $count = mysqli_num_rows($getnumber);
                                                   Session::set('count', $count);
                                               ?>  
                                                
                                                
                                                
                                                
                                                 <tr>
                                                  <td>Number of payment</td>
                                                  <td colspan="2"><?php echo $count; ?>  // <a style="color:#DB0D15;" href="sthsonchoy.php?customerId=<?php echo Session::get("customerId"); ?>"> More</a></td>
                                                  
                                                </tr>
                                                
                                                   <?php } ?>     
                                                
                                                
                                                
                                               <?php
                                                $getsthayisonchoy = $loan->getsthayisonchoy($id);
                                                if($getsthayisonchoy){
                                                    while ($result = $getsthayisonchoy->fetch_assoc()){

                                               ?>   
                                                
                                                <tr>
                                                  <td>Duration of permanent saving</td>
                                                  <td colspan="2"><?php echo $result['duration']; ?> Year</td>
                                                  
                                                </tr>
                                                
                                               
                                                
                                                <tr>
                                                    <td>payment</td>
                                                  <td colspan="2"><?php echo $result['aday']; ?> Taka</td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Profit</td>
                                                  <td colspan="2"><?php echo $result['munafa']; ?> Taka</td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Total at the end of the expiration</td>
                                                  <td colspan="2"><?php echo $result['inTotal']; ?> Taka</td>
                                                 
                                                </tr>

                                                <?php } } ?>