 <!--       Bima information-->
                                           
                                        <tr>
                                                  
                                                    <td style="text-align: center; background: #FF9800" colspan="3">DPS</td>
                                                  
                                                </tr>
                                                
                                                <?php 
                                                   $getBima = $loan->getBima($id);
                                                   if($getBima){
                                                    while($row = $getBima->fetch_assoc()){
                                                    $bimaadayy  = $row['sum(monthlyAday)']; 
                                                    $bimautto = Session::get("bimauttolon");
                                                    $currentBalnce = $bimaadayy - $bimautto;
                                                    Session::set('currentBalnce', $currentBalnce);
                                                    $datee = Session::get("datee");
                                                    
                                                     
                                                ?>
                                            
                                                 <tr>
                                                  <td>Current Balance and profit</td>
                                                  <td colspan="2"><?php echo $currentBalnce; ?> Taka ||
                                                 <?php
                                                      $getdatee = $dateMonth->agecal($datee);
                                                      echo $getdatee;  
                                                  ?> ||    
                                                  
                                                  <?php 
                                                  $duraion = Session::get("bimaDuration");
                                                  $pmt = Session::get("dpspayment");
                                                  $paycount = Session::get("bimacount");
                                                  $cbalance = Session::get("currentBalnce");
                                                  
                                                  $interest = $dateMonth->compoundinterset($duraion, $pmt, $paycount, $bimaadayy);
                                                  $getDpsProfitLift = $loan->getDpsProfitLift($id);
                                                  if($getDpsProfitLift){
                                                      while ($row = $getDpsProfitLift->fetch_assoc()){
                                                          $liftProfit = $row['sum(profit_lift)'];
                                                          $interestt = $interest- $liftProfit;
                                                           $interesttt  = $interestt-$cbalance;
                                                          echo 'Interest :' .round($interestt);
                                                      }    
                                                  }
                                                  
                                                  ?> 
                                                  <?php 
//                                                  $getDpsProfitttt = $loan->getDpsProfit($id);
//                                                  if($getDpsProfitttt){
//                                                      while ($row = $getDpsProfitttt->fetch_assoc()){
//                                                      $getDpsProfit = $row['sum(profit)'];    
//                                                  if(empty($getDpsProfit)){
//                                                  $dpsprofitinsert = $loan->dpsprofitinsert($id, $interesttt);
//                                                  echo $dpsprofitinsert;
//                                                  } else {
//                                                   $dpsProfitUpdate = $loan->dpsProfitUpdate($id, $interesttt);
//                                                   echo $dpsProfitUpdate;
//                                                  }
//                                                  }
//                                                 }  
                                                  ?>
                                                  
                                                      
                                                  </td>
                                   
                                                </tr>
                                                
                                                <tr>
                                                  <td>Total lifted</td>
                                                  <td colspan="2"><?php echo $bimautto; ?> Taka  // <a style="color:#DB0D15;" href="bimauttolonlist.php?customerId=<?php echo Session::get("customerId"); ?>"> More</a></td>
                                                  
                                                </tr>
                                                
                                                 <tr>
                                                  <td>Intotal with lifted</td>
                                                  <td colspan="2"><?php echo $bimaadayy; ?> Taka</td>
                                                  
                                                </tr>
                                                
                                             <?php } } ?>
                                              
                                        <?php 
                                        $getBimaUttolon = $loan->getBimaUttolon($id);
                                         if($getBimaUttolon){
                                         while($row = $getBimaUttolon->fetch_assoc()){
                                         $bimauttolon  = $row['sum(bimaUttolon)'];
                                         Session::set('bimauttolon', $bimauttolon);
                                         }
                                        } 
                                        ?>
                                                
                                                
                                                
                                                
                                             <?php 
                                                 $getBimacounter = $loan->getBimacounter($id);
                                                    
                                                   if($getBimacounter){
                                                     
                                                   $bimacount = mysqli_num_rows($getBimacounter);
                                                    Session::set('bimacount', $bimacount);
                                               ?>  
                                                
                                                
                                                
                                                
                                                 <tr>
                                                  <td>Number of payment</td>
                                                  <td colspan="2">
                                                   <?php  echo $bimacount;?>  // <a style="color:#DB0D15;" href="bimalist.php?customerId=<?php echo Session::get("customerId"); ?>"> More</a></td>
                                                  
                                                </tr>
                                                
                                                <?php } ?>     
                                                
                                                
                                                
                                               <?php
                                                $getallbima = $loan->getallbima($id);
                                                if($getallbima){
                                                    while ($result = $getallbima->fetch_assoc()){

                                               ?>   
                                                
                                                <tr>
                                                  <td>Date </td>
                                                  <td colspan="2">
                                                      <?php 
                                                      echo $result['datee'];
                                                       Session::set('datee', $result['datee']);
                                                      ?> </td>
                                                      
                                                  
                                                </tr>
                                                
                                                
                                                
                                                <tr>
                                                  <td>Duration </td>
                                                  <td colspan="2">
                                                      <?php 
                                                      echo $result['bimaDuration'];
                                                       Session::set('bimaDuration', $result['bimaDuration']);
                                                      ?> Year</td>
                                                      
                                                  
                                                </tr>
                                                
                                               
                                                
                                                <tr>
                                                    <td>DPS payment</td>
                                                  <td colspan="2"><?php
                                                  echo $result['bimaAday'];
                                                  Session::set('dpspayment', $result['bimaAday']);
                                                  ?> Taka</td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Profit</td>
                                                  <td colspan="2"><?php echo $result['bimaMunafa']; ?> Taka</td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Total at the end of the expiration</td>
                                                  <td colspan="2"><?php echo $result['bimaInTotal']; ?> Taka</td>
                                                 
                                                </tr>

                                                <?php } } ?>
                           