
<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
$id = Session::get("customerId");
$type = Session::get("loanType");




if(isset($_POST['submit'])) {
    $srcbyid = $srce->search($_POST);
   
}elseif(isset($_POST['kisti'])) {
     $addKistibyid = $srce->addkisti($_POST, $id, $type);
}elseif(isset($_POST['General'])) {
     $addGNbyid = $srce->addGnsonshoy($_POST, $id);
}elseif(isset($_POST['sthayi'])) {
     $addSthayiyid = $srce->addSthayisonshoy($_POST, $id);
}elseif(isset($_POST['bima'])) {
   $addmonthlyBima = $srce->addmonthlyBima($_POST, $id); 
}

?>





<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Payment sheet:</h2>
          
<div class="row-fluid">
			
            <div class="box-content">
 
                <table class="mytable">
                    <tr>
                        <td style="background: #FFCE42">
                            <h2 style="background: #F25022;"> Search By Id Or Name || Current Id is : <?php echo Session::get("customerId"); ?></h2>
                         
                            <form action="" method="POST">
                                
                                <input type="text" name="search"/>
                                <select name="name">
                                    <option>select</option>
                                    <?php 
                                    $getName = $customer->getAllCustomerForSearch();
                                    if($getName){
                                        while ($result = $getName->fetch_assoc()){
                                             
                                    ?>
                                    <option value="<?php echo $result['CustomerName']; ?>"><?php echo $result['CustomerName']; ?></option>
                                    <?php } } ?>               
                                </select>                            
                              
                              <input type="submit" name="submit" value="Search"/>
                              
                            </form>
                        </td>
                        <td style="background: #FDF0F1">
                            <h2> Payment</h2>
                           <?php 
                            if(isset($addKistibyid)){
                                echo $addKistibyid;
                            }
                            ?>
                            <form action="" method="POST">
                               Payment <input type="text" name="kistiaday"/>
                                <input type="submit" name="kisti" value="Add payment"/>
                                
                            </form>
                        </td>
                        
                    </tr>
                    
                      <tr>
                          <td style="background: #FDF0F1">
                              <h2> General saving </h2>
                           <?php 
                            if(isset($addGNbyid)){
                                echo $addGNbyid;
                            }
                            ?>
                              
                            <form action="" method="POST">
                               General saving <input type="text" name="gnsonchoyaday"/>
                                <input type="submit" name="General" value="Add G. Saving"/>
                                
                            </form> 
                              
                          </td>
                          
                          
                           <td style="background: #FDF0F1">
                              <h2> Perment saving</h2>
                              
                           <?php 
                            if(isset($addSthayiyid)){
                                echo $addSthayiyid;
                            }
                            ?>
                              
                            <form action="" method="POST">
                               Perment saving <input type="text" name="sthayiaday"/>
                                <input type="submit" name="sthayi" value="Add P. saving"/>
                                
                            </form> 
                              
                          </td>
                      
                        
                 </tr>
                 
                 <tr>
                 
                         <td style="background: #FDF0F1">
                              <h2> Insurance payment</h2>
                              
                           <?php 
                            if(isset($addmonthlyBima)){
                                echo $addmonthlyBima;
                            }
                            ?>
                              
                            <form action="" method="POST">
                               Insurance payment <input type="text" name="monthlyAday"/>
                                <input type="submit" name="bima" value="Add insurance"/>
                                
                            </form> 
                              
                          </td>
                      
                        
                 </tr>
                 
               <?php 
               if(empty($srcbyid)){
                   echo "<span style= color:red;>Please enter a customer Id or Name!<span>";
               }else {
               while ($result = $srcbyid->fetch_assoc()){ 
                   
                   Session::set('customerId',$result['customerId']);
                   Session::set('loanType',$result['loanType']);
                   echo $result['loanType'];
               
               ?>
             
              <img style="float: right; width: 250px; height: 300px; border-radius: 5px;" src="<?php echo $result['customerPhoto'];?>"/>

                </table>
                
                       <table border="2" class="table1" style="width:100%">
     
                                                  <tr>
                                                
                                                      <td colspan="3" style="text-align: center;  background: #46B82F">Customer  Information</td>
                                                    
                                                </tr>
                                             
                                                
                                                
                                                
                                                <tr>
                                                  <td width="30%">Customer Name</td>
                                                  <td colspan="2"><?php echo $result['CustomerName']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Customer Area</td>
                                                  <td colspan="2"> <?php echo $result['customerArea']; ?></td>
                                                  
                                                </tr>
                                                
                                               
                                                
                                                <tr>
                                                  <td>Customer Father Name</td>
                                                  <td colspan="2"><?php echo $result['cusfatherName']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Customer Mother Name</td>
                                                  <td colspan="2"><?php echo $result['cusmotherName']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Cutomer Village</td>
                                                  <td colspan="2"><?php echo $result['cusvillage']; ?> </td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Customer Mobile Number</td>
                                                  <td colspan="2"> <?php echo $result['cusmobileNumber']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td>Join Date</td>
                                                  <td colspan="2"><?php echo $result['cusJoinDate']; ?></td>
                                                  
                                                </tr>
                                                
                                                 <tr>
                                                  <td>Id</td>
                                                  <td colspan="2"><?php echo $result['customerId']; ?></td>
                                                  
                                                </tr>
                                                
                                              
                                              <?php } } ?>  
                                               
                                              </table> 
                                                         
                

            </div>









				
				
</div>

</div><!--/.fluid-container-->





<?php include'inc/footer.php'; ?>