<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>

<?php
if(isset($_GET['delUser'])){
    $id = $_GET['delUser'];
    $delUser = $usr->delUser($id);
    
}

?>
          
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >User List:</h2>
         
		<div class="row-fluid">
			
					<div class="box-content">
                                           
                                          
                                            
                                           <table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>Name</th>
								  <th>Joining Date</th>
								  <th>Role</th>
								  <th>Status</th>
								  <th>Actions</th>
							  </tr>
						  </thead> 
                                                  
                                           <?php
                                             $getAllUser = $usr->getAllUser();
                                             if($getAllUser ){
                                                 while($result = $getAllUser->fetch_assoc()){
                                        
                                            ?>   
                                                  
                                                  
						  <tbody>
							<tr>
                                                            <td><?php echo $result['adminName']; ?></td>
								<td class="center"><?php echo $result['date']; ?></td>
								<td class="center"><?php echo $result['userName']; ?></td>
								<td class="center">
                                                                    <?php 
                                                                     if($result['adminRole']== 1){
                                                                         echo '<span class="label label-success">Active</span>';  
                                                                     }elseif ($result['adminRole']== 2) {
                                                                          echo '<span class="label label-success">Active</span>'; 
                                                                            } elseif($result['adminRole']== 3) {
                                                                                 echo '<span class="label label-success">Active</span>';
                                                                            } else {
                                                                               echo '<span class="label label-important">Banned</span>';     
                                                                            }
                                                                            
                                                                       
                                                                    ?>
									
								</td>
								<td class="center">
                                                                    <a class="btn btn-success" href="profile.php?adminId=<?php echo $result['adminId']; ?>">
										<i class="halflings-icon white zoom-in"></i>  
									</a>
									<a class="btn btn-info" href="edit.php?editUser=<?php echo $result['adminId']; ?>">
										<i class="halflings-icon white edit"></i>  
									</a>
									<a onclick="return confirm('Are you sure to Delete !')" class="btn btn-danger" href="?delUser=<?php echo $result['adminId']; ?>">
										<i class="halflings-icon white trash"></i> 
									</a>
								</td>
							</tr>
							
						  </tbody>
                                                  
                                             <?php } } ?>       
                                                  
					  </table>
                                            

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>