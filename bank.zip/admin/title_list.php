<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>


<?php
if(isset($_GET['deltitle'])){
    $id = $_GET['deltitle'];
    $deltitle = $front->deltitl($id);
    
}

?>
    
  
                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #45B52E; padding: 10px; border-radius: 4px;" >Customer List:</h2>
         
		<div class="row-fluid">
			
					<div class="box-content">
                                           
                                          
                                            
                                           <table class="table table-striped table-bordered bootstrap-datatable datatable">
						  <thead>
							  <tr>
								  <th>id</th>
								  <th>Title</th>
								  <th>Footer title</th>                             
								  <th>Actions</th>
							  </tr>
						  </thead> 
                                                  
                                           <?php
                                             $addtitlelist = $front->addtitlelist();
                                             if($addtitlelist){
                                                 while($result = $addtitlelist->fetch_assoc()){
                                               
                                            ?>   
                                                  
                                                  
						  <tbody>
							<tr>
                                                                
								<td class="center"><?php echo $result['id']; ?></td>
                                                                <td class="center"><?php echo $fm->textShorten($result['title'],100); ?></td>
								<td class="center"><?php echo $fm->textShorten($result['ftitle'],100); ?></td>
                                                          
                                                                
								
								<td class="center">
  
									<a onclick="return confirm('Are you sure to Delete !')" class="btn btn-danger" href="?deltitle=<?php echo $result['id']; ?>">
										<i class="halflings-icon white trash"></i> 
									</a>

								</td>
							</tr>
							
						  </tbody>
                                             <?php } } ?>
                                                  
					  </table>
                                            

					</div>









				
				
	</div>

</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?>