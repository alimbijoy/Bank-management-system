<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>



		
  <!-- start: Content -->
 <div id="content" class="span10">
  
                  
    <!--	Start-->
      <div class="row-fluid">

    <table border="2" class="table1" style="width:100%; margin: 5px; ">

                        <tr>

                              <td colspan="6" style="text-align: center;  background: #DE5448">DPS information</td>

                        </tr>
                      <?php
                      $fix_deposit_date = $fixedDeposit->getFixedDepositDate();
                       if($fix_deposit_date){
                           while ($row = $fix_deposit_date->fetch_assoc()){
                              $datee = $row['cusJoinDate']; 
                           } 
                       }
                      date_default_timezone_set('Asia/Dhaka');
                      $today = date("h:i:s a");
                      $getdate = $dateMonth->agecal($datee);

                      $date=date("d");
                     
                      ?>  
                        
                        <tr>
                            <td style="font-size: 28px; color:#304BBE; text-align: center; padding: 10px"><?php echo $getdate ." ".$today ?></td>
                        
                        </tr>
                        
                    
                     <?php
                      $getMonth = $dateMonth->monthcount($datee);
                       $totalamount   = Session::get("totalfixed_deposit");
                       $divfix       = $totalamount/1000;
                       for($i=1; $i<=$getMonth; $i++){
                        if ($date==28) {
                            continue; } 
                       $fixpersent   = $divfix * 1.5; 
                       
                      ?> 
                     <tr>
                      <td  style="font-size: 24px; color:#000; text-align: center; padding: 10px; background: #FFFFFF"> <?php  echo $i. "profit intotal : ".$fixpersent; ?> TK. </td> 
                    </tr> 
                    
                   <?php  } ?>

               </table>  

      </div>
                  
                  
  <!--		end-->

    
</div><!--/.fluid-container-->
        
        
        
	<?php include'inc/footer.php'; ?>