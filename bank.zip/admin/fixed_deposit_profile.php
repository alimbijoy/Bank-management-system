
<?php
  $url1=$_SERVER['REQUEST_URI'];
  header("Refresh: 2; URL=$url1");
?>


<?php include 'inc/header.php'; ?>
<?php include 'inc/sidebar.php'; ?>



<?php 
  if(isset($_GET['viewdeposit'])||$_GET['viewdeposit']==NULL){
     $depositid = $_GET['viewdeposit'];
     
     $depositById = $fixedDeposit->depositById($depositid);
  }
?>
 



                        
			<!-- start: Content -->
<div id="content" class="span10" style="background-color: #4B15BE">			
          <h2 style="background: #FF9800; padding: 10px; border-radius: 4px;" > Fixed deposit customer profile:</h2>
         
		<div class="row-fluid">
			
					<div class="box-content">
                                            
                                            <table border="2" class="table1" style="width:100%">
                                                <?php 
                                                    if($depositById){
                                                        while($result = $depositById->fetch_assoc()){?>
                                                

                                                
                                                <tr>
                                                  <th style="width:30%"><a href="fixed_deposit_edit.php?editdepsit=<?php echo $result['id']; ?>">Edit Profile</a></th>
                                                  <th style="width:40%">Customer Details</th>
                                                  <th style="width:30%">Photo</th>
                                                </tr>
                                                <tr>
                                                  <td>Name</td>
                                                  <td><?php echo $result['CustomerName']; ?></td>
                                                  <td rowspan="6" bgcolor="#E3F2E1"><img style=" width: 250px; height: 300px; border-radius: 5px;"  src="<?php echo $result['customerPhoto']; ?>" class="img-responsive img-rounded" alt="Responsive image"/></td>
                                                </tr>
                                                <tr>
                                                  <td>Amount</td>
                                                  <td>
                                                   <?php
                                                  $amount = $result['amount'];
                                                   echo $amount;
                                                  ?> || 
                                                      Per year 15% of 1000 || <?php
                                                      $div = $result['amount']/1000;
                                                      $persent = $div*1.5;
                                                      echo "you get ". $persent;
                                                  ?> taka per month</td>
                                                 
                                                </tr>
                                                
                                                  <tr>
                                                  <td>পরিমান কথায়</td>
                                                  <td><?php echo $result['amountkothay']; ?></td>
                                                 
                                                </tr>
                                                
                                                <tr>
                                                  <td>Mobile</td>
                                                  <td><?php echo $result['cusmobileNumber']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td> Starting date</td>
                                                  <td>
                                                      <?php
                                                      $datee = $result['cusJoinDate'] ;
                                                      echo $datee;
                                                      ?>
                                                  </td>
                                                 
                                                </tr>
                                                
                                                <tr>
                                                  <td>Date by computer</td>
                                                  <td><?php echo $result['date']; ?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td colspan="1">Nomoni Name</td>
                                                  <td colspan="2"> <?php echo $result['nomoniname'];?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td colspan="1">Nomoni age</td>
                                                  <td colspan="2"> <?php echo $result['nomoniage'];?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  <td colspan="1">Rilation</td>
                                                  <td colspan="2"> <?php echo $result['rilation'];?></td>
                                                  
                                                </tr>
                                                
                                                <tr>
                                                  
                                                  <td colspan="3">Address: <?php echo $result['cusvillage'].', '.$result['cuspost'].', '. $result['custhana'].', ' . $result['cusDistrict'].', ' . $result['cusmobileNumber']; ?></td>
                                                  
                                                </tr>
                                                
                                                    
                                                
                                                
                                              <tr>
                                                    <td colspan="3">  
                                                     <a class="btn btn-primary" href="fixed_deposit_profit_lift.php?id=<?php echo $result['id']; ?>">Profit lift</a>
                                                  </td> 
                                                </tr>
                                             <?php } } ?>
                                                
                                                 <tr>
                                                  <?php 
                                                   $getfixprofitlift = $fixedDeposit->getfixprofitlift($depositid);
                                                   if($getfixprofitlift){
                                                       while ($result = $getfixprofitlift->fetch_assoc()){
                                                           $row = $result['sum(Profit_amount)'];
                                                   
                                                  ?>   
                                                   <td colspan="1">Lift amount</td>
                                                   <td colspan="2">
                                                    <?php
                                                    echo $row; 
                                                     Session::set('row', $row);
                                                    ?> Taka || 
                                                    Total payable profit : 
                                                    <?php
                                              
                                                    $payable = Session::get("sum")- $row;
                                                    Session::set('payable', $payable);
                                                    echo "<span style='color:red;'>" .$payable."<span>";
                                                    ?> 
                                                    || <a href="fixdeposit_lift_list.php?depositid=<?php echo $depositid; ?>">More</a>
                                                   </td>
                                                   <?php } } ?>
                                                </tr>
                                                
                                                
                                              </table> 
                                           

					</div>

                                                     
                                <!--	Start-->
                                  <div class="row-fluid">

                                <table border="2" class="table1" style="width:100%; margin: 5px; ">

                                                    <tr>

                                                          <td colspan="6" style="text-align: center;  background: #FF9800">Profit information</td>

                                                    </tr>
                                                  <?php
                                                  $getdate = $dateMonth->agecal($datee);
                                                  ?>  

                                                    <tr>
                                                        <td style="font-size: 20px; color:#E21E27; text-align: center; padding: 10px"><?php echo $getdate; ?>|| Amount : <?php echo $amount; ?> || Total Profit : <?php echo Session::get("sum"); ?> || Intotal : <?php echo $amount+Session::get("sum")-Session::get("row"); ?> TK.</td>

                                                    </tr>

                                                 <?php
                                                 $getmonth = $dateMonth->monthcount($datee);

                                                 if($getmonth){
                                                  $in = 0;
                                                  $sum =0;
                                                 for($i = 1; $i<=$getmonth; $i++){
                                                   
                                                   $sum = $i*$persent;
                                                   Session::set('sum', $sum);



                                                ?>  
                                                 <tr>

                                                  <td  style="font-size: 24px; color:#000; text-align: center; padding: 10px; background: #FFFFFF"> <?php  echo $i. " month interest is : " .( round($persent) ). " profit intotal : ".$sum; ?> TK. </td> 
                                                 </tr> 

                                                 <?php } } ?>

                                           </table>  

                                  </div>


                              <!--		end-->
		
				
	</div>

          
       <?php 
       
       $datecal = $dateMonth->datecal($datee);
       $getfixdpsprofit = $fixedDeposit->getfixdpsprofit($depositid);
       if(empty($getfixdpsprofit)){
           $insertdpsprofit =$fixedDeposit->insertdpsprofit( $depositid, $sum); 
           echo $insertdpsprofit;
       }else{
        $updatedpsprofit =$fixedDeposit->updatedpsprofit( $depositid, $sum);
        echo $updatedpsprofit;
         }
        
       ?>    
          
          
          
          
</div><!--/.fluid-container-->
	
<?php include'inc/footer.php'; ?><?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

