
<?php

 include'../lib/Session.php';
 Session::checkSession();
 include'../helpers/Format.php';
spl_autoload_register(function($class){
  include "../classes/".$class.".php";
});

 ?>



<?php
  //set headers to NOT cache a page
  header("Cache-Control: no-cache, must-revalidate"); //HTTP 1.1
  header("Pragma: no-cache"); //HTTP 1.0
  header("Expires: Sat, 26 Jul 1997 05:00:00 GMT"); 
  // Date in the past
  //or, if you DO want a file to cache, use:
  header("Cache-Control: max-age=2592000"); 
//30days (60sec * 60min * 24hours * 30days)
?>


<?php
$fm = new Format();
$usr = new Userrole();
$customer = new Customer();
$loan = new Loan();

$srce = new Search();



?>






<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Micro credit</title>
        
        <script>
        function myFunction() {
            window.print();
        }
        </script>


	<style>
		body{width: 960px;  margin: 0 auto; padding: 0px; overflow: hidden; }
		
		.header{background: #E2FA9B; margin:0px; padding: 0; overflow: hidden; border: 2px solid #000;}
		.header img{ float: left;
                         
		         width: 100px;
		         height: 100px; 
		         border-radius: 4px; 
		         margin: 5px; 
		        border-radius: 4px;}
		.title{text-align: center; padding: 5px; font-size: 30px; margin: 0; padding: 0; color: #FA2433;}
                
		.descrip{text-align: center; padding: 5px; margin: 0; padding: 0; font-size: 20px; color: #FA2433}
		.content{overflow: hidden;}
		.content img{ padding: 0; width: 150px; height: 160px; margin-top: 5px;  border-radius: 4px; margin-right: 2px; margin-bottom: 5px; float: right}
		.footer{margin-bottom: 0px; padding: 0px; overflow: hidden; border: 2px solid #000;}
		table td, th{border: 1px solid #000; padding: 3px; font-size: 18px; color: #16A05D}
	</style>
</head>
<body>
    
    
<div class="main">
   
	<div class="header">
		<img  src="upload/logo.jpg">
		<h2 class="title">একতা সঞ্চয় ও ঋণদান সমবায় সমিতি লিঃ</h2>
		<p class="descrip"> স্থাপিতঃ 2016 ইং <br/> নিকরাইল বাজার, ভূঞাপুর, টাঙ্গাইল। মোবাইলঃ 01742689979</p>
	</div>
    <?php
        if(isset($_GET['customerId'])){
            $id = $_GET['customerId'];
            Session::set('id', $id);
           $printcustomer = $loan->printcustomer($id);
         
           if($printcustomer){
               while ($result = $printcustomer->fetch_assoc()){
                   
    
        ?>
    
        <div class="content">
		  <div class="image">
                      <img src="<?php echo $result['customerPhoto']; ?>">	
		  </div>
          </div>
          	
         
 	 <table style="width: 475px; float: left; background: #FFFFFF"; border="1px solid #000;" >
				  <tr>
                                      <th style="font-size:28px;" colspan="2">Customer information</th>
				    
				  </tr>
				  <tr>
				    <td width="60%">Your Id No</td>
				    <td><?php echo Session::get("id"); ?></td>
				  </tr>

				  <tr>
				    <td>Name</td>
				    <td><?php echo $result['CustomerName']; ?></td>
				  </tr>

				  <tr>
				    <td>Customer Father Name</td>
				    <td><?php echo $result['cusfatherName']; ?></td>
				  </tr>
                                  
                                  <tr>
				    <td>Customer Mother Name</td>
				    <td><?php echo $result['cusmotherName']; ?></td>
				  </tr>
                                  
                                  <tr>
				    <td>Village</td>
				    <td><?php echo $result['cusvillage']; ?></td>
				  </tr>
                                  
                                  <tr>
				    <td>Post</td>
				    <td><?php echo $result['cuspost']; ?></td>
				  </tr>
                                  
                                  <tr>
				    <td>Thana</td>
				    <td><?php echo $result['custhana']; ?></td>
				  </tr>
                                  
                                  <tr>
				    <td>District</td>
				    <td><?php echo $result['cusDistrict']; ?></td>
				  </tr>
                                  <tr>
				    <td>Gender</td>
				    <td><?php echo $result['cusgender']; ?></td>
				  </tr>
                                  <tr>
				    <td>NID/Birght Registration Number</td>
				    <td><?php echo $result['cusnid']; ?></td>
				  </tr>
                                  <tr>
				    <td>Joining Date</td>
				    <td><?php echo $result['cusJoinDate']; ?></td>
				  </tr>
                                  
			</table>

			 <table style="width: 475px; float: right; background: #FFFFFF; border:1px solid #000;" >
				  <tr>
				   <th style="font-size:28px;" colspan="2">Loan and Bima information</th>
				   
				  </tr>
				  <tr>
				    <td width="60%">Loan type</td>
				    <td><?php echo $result['loanType']; ?></td>
				  </tr>

				  <tr>
				    <td>Amount</td>
				    <td><?php echo $result['amount']; ?></td>
				  </tr>

				
                                  
                                  <tr>
				    <td>Loan delivary Date</td>
				    <td><?php echo $result['startDate']; ?></td>
				  </tr>
                                  
                                  <tr>
				    <td>Loan ending Date</td>
				    <td><?php echo $result['endDate']; ?></td>
				  </tr>
                                  
                                  <tr>
				    <td>Kisti</td>
				    <td><?php echo $result['kisti']; ?></td>
				  </tr>
                                  
                                  <tr>
				    <td>Total Kisti</td>
				    <td><?php echo $result['totalKisti']; ?></td>
				  </tr>
                                  
                                  <tr>
				    <td>Loan Bima</td>
				   <td><?php echo $result['loanBima']; ?></td>
				  </tr>
                                  <tr>
				    <td>Sthayi Sonchoy Meyad</td>
				    <td><?php echo $result['duration']; ?></td>
				  </tr>
                                  <tr>
				    <td>Aday</td>
				    <td><?php echo $result['aday']; ?></td>
				  </tr>
                                  <tr>
				    <td>Total profit end of the expiration</td>
				    <td><?php echo $result['munafa']; ?></td>
				  </tr>
                                   <tr>
				    <td>Total at the end of the expiration</td>
				    <td><?php echo $result['inTotal']; ?></td>
				  </tr>
			</table>  
          		
          	
		  </div>
        <?php } } } ?>
		</div>
    <button style="margin-top:10px; margin-bottom: 5px;" onclick="myFunction()">Print this page</button>
    <a style="float: right; background: #dddd; margin-top: 5px; border-radius: 2px; padding: 3px;" href="http://localhost/bank/admin/index.php">Back to Dashboard</a>
                <div class="footer">
                    <p style="margin:0; padding: 0;">
                                    <span style="text-align:center; overflow: visible; background: #251C22; display: block; color: #ffff; padding: 5px; color: #FF3228">Copyright &copy;একতা সঞ্চয় ও ঋণদান সমবায় সমিতি লিঃ All rights reserved</span>

                            </p>
                    </div>		
	
</div>


    
    
</body>
</html>