<!-- banner section -->
<div class="banner-slider">
				<div class="container">
						<!--Slider-->	
				<div class="callbacks_container">
					<ul class="rslides" id="slider3">
                                           <?php  
                                            $getSlider = $front->getSlider();
                                            if($getSlider){
                                                while ($result = $getSlider->fetch_assoc()){
                                                    
                                         
                                           ?> 
                                            
						<li>
							<div class="w3l_banner_info">
                                                            <h3><?php echo $result['title']; ?></h3>
                                                            <p >  <?php echo $fm->textShorten($result['description'],200); ?></p>
								<div class="agileits_w3layouts_more menu__item">
									<a href="#" class="menu__link" data-toggle="modal" data-target="#myModal">Learn More</a>
								</div>
							</div>
						</li>
						
                                            <?php } } ?>	
						
					</ul>
				</div>
				

				</div>
</div>
<!-- //Slider -->


<!-- Modal1 -->
<div class="modal fade" id="myModal" tabindex="-1" role="dialog">
	<div class="modal-dialog">
		<!-- Modal content-->
		<div class="modal-content">
			<div class="modal-header">
				<button type="button" class="close" data-dismiss="modal">&times;</button>
					<img src="images/g7.jpg" alt=" " class="img-responsive">
					<h5>Donec lobortis pharetra dolor</h5>
					<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, rds which don't look even slightly believable..</p>
			</div>
		</div>
		<!-- //Modal content-->
	</div>
</div>
<!-- //Modal1 -->
<!-- //banner section -->