
<!-- about -->
<div class="about" id="about">
	<div class="container">
		<h3 class="w3l-title"><span>About</span> Us</h3>
		<div class="w3-agileits-about-grids">
			<div class="col-md-5 agile-about-right">
				<img src="images/3.png" alt="" />
			</div>
			<div class="col-md-7 agile-about-left">
				<h3 class="w3l-sub">Offering the most </h3>
				<p class="sub-p">competitive rates and fees</p>
				<p class="sub-p2">Lorem ipsum dolor sit amet, do eiusmod magna aliqua</p>
				<p class="sub-p3">Lorem ipsum dolor sit amet, do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
			</div>
			<div class="clearfix"> </div>
		</div>
	</div>
</div>
<!-- //about -->
