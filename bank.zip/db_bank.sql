-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 26, 2018 at 03:42 AM
-- Server version: 10.1.29-MariaDB
-- PHP Version: 7.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_bank`
--

-- --------------------------------------------------------

--
-- Table structure for table `btl_sthayi_sonchoy_aday`
--

CREATE TABLE `btl_sthayi_sonchoy_aday` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `sthayiaday` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `fornt_slider`
--

CREATE TABLE `fornt_slider` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `fornt_slider`
--

INSERT INTO `fornt_slider` (`id`, `title`, `description`, `image`, `date`) VALUES
(18, 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. ', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. \r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.    \r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. \r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. \r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.                                                     ', 'upload/7ef393c112.jpg', '2018-05-06 05:56:41'),
(19, 'Alim multimedia', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. \r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. \r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. \r\nLorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.                                                                     \r\n                                                              ', 'upload/5be4d26a13.jpg', '2018-05-06 05:57:30'),
(20, 'à¦—à¦¾à¦› à¦²à¦¾à¦—à¦¾à¦¨ à¦ªà¦°à¦¿à¦¬à§‡à¦¶ à¦¬à¦¾à¦šà¦¾à¦¨', ' à¦—à¦¾à¦› à¦²à¦¾à¦—à¦¾à¦¨ à¦ªà¦°à¦¿à¦¬à§‡à¦¶ à¦¬à¦¾à¦šà¦¾à¦¨à¥¤ à¦—à¦¾à¦› à¦²à¦¾à¦—à¦¾à¦¨ à¦ªà¦°à¦¿à¦¬à§‡à¦¶ à¦¬à¦¾à¦šà¦¾à¦¨    à¦—à¦¾à¦› à¦²à¦¾à¦—à¦¾à¦¨ à¦ªà¦°à¦¿à¦¬à§‡à¦¶ à¦¬à¦¾à¦šà¦¾à¦¨                                                            \r\n                                                              ', 'upload/0e3c77e371.jpg', '2018-05-06 06:01:30'),
(21, 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor. ', 'Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.                                                             \r\n  Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.  Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Aenean commodo ligula eget dolor.                ', 'upload/f4b460f614.jpg', '2018-05-06 06:06:50');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_area`
--

CREATE TABLE `tbl_area` (
  `areaId` int(11) NOT NULL,
  `areaName` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_balnce`
--

CREATE TABLE `tbl_balnce` (
  `id` int(11) NOT NULL,
  `balance` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_balnce_uttolon`
--

CREATE TABLE `tbl_balnce_uttolon` (
  `id` int(11) NOT NULL,
  `uttolon` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bima`
--

CREATE TABLE `tbl_bima` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `bimaDuration` int(11) NOT NULL,
  `datee` varchar(255) NOT NULL,
  `bimaAday` int(11) NOT NULL,
  `bimaMunafa` int(11) NOT NULL,
  `bimaInTotal` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bima_aday`
--

CREATE TABLE `tbl_bima_aday` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `monthlyAday` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_bima_uttolon`
--

CREATE TABLE `tbl_bima_uttolon` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `bimaUttolon` int(11) NOT NULL,
  `profit_lift` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_cost`
--

CREATE TABLE `tbl_cost` (
  `id` int(11) NOT NULL,
  `costName` varchar(255) NOT NULL,
  `cost` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_customer`
--

CREATE TABLE `tbl_customer` (
  `customerId` int(11) NOT NULL,
  `customerArea` varchar(255) NOT NULL,
  `CustomerName` varchar(255) NOT NULL,
  `cusfatherName` varchar(255) NOT NULL,
  `cusmotherName` varchar(255) NOT NULL,
  `cusvillage` varchar(255) NOT NULL,
  `cuspost` varchar(255) NOT NULL,
  `custhana` varchar(255) NOT NULL,
  `cusDistrict` varchar(255) NOT NULL,
  `cusgender` varchar(255) NOT NULL,
  `cusnid` varchar(255) NOT NULL,
  `cusmobileNumber` varchar(255) NOT NULL,
  `cusJoinDate` varchar(255) NOT NULL,
  `cusdateOfBirth` varchar(255) NOT NULL,
  `customerPhoto` varchar(255) NOT NULL,
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `cuslevel` int(11) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dps_profit`
--

CREATE TABLE `tbl_dps_profit` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `dps_profit` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_dps_totalprofit`
--

CREATE TABLE `tbl_dps_totalprofit` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `profit` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fixed_deposit`
--

CREATE TABLE `tbl_fixed_deposit` (
  `id` int(11) NOT NULL,
  `amount` int(11) NOT NULL,
  `amountkothay` varchar(255) NOT NULL,
  `CustomerName` varchar(255) NOT NULL,
  `cusfatherName` varchar(255) NOT NULL,
  `cusmotherName` varchar(255) NOT NULL,
  `cusvillage` varchar(255) NOT NULL,
  `cuspost` varchar(255) NOT NULL,
  `custhana` varchar(255) NOT NULL,
  `cusDistrict` varchar(255) NOT NULL,
  `cusgender` varchar(255) NOT NULL,
  `cusnid` varchar(255) NOT NULL,
  `cusmobileNumber` varchar(255) NOT NULL,
  `cusJoinDate` varchar(255) NOT NULL,
  `cusdateOfBirth` varchar(255) NOT NULL,
  `nomoniname` varchar(255) NOT NULL,
  `nomoniage` varchar(255) NOT NULL,
  `rilation` varchar(255) NOT NULL,
  `customerPhoto` varchar(255) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_fixed_deposit_lift`
--

CREATE TABLE `tbl_fixed_deposit_lift` (
  `id` int(11) NOT NULL,
  `Profit_amount` int(11) NOT NULL,
  `amountkothay` varchar(255) NOT NULL,
  `lift_date` varchar(255) NOT NULL,
  `fix_deposit_cmr_id` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_general_saving_profit`
--

CREATE TABLE `tbl_general_saving_profit` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `profit` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_general_sonchoy_aday`
--

CREATE TABLE `tbl_general_sonchoy_aday` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `gnsonchoyaday` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_general_sonchoy_uttolon`
--

CREATE TABLE `tbl_general_sonchoy_uttolon` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `gnuttolon` int(11) NOT NULL,
  `gnprofit` int(11) NOT NULL,
  `gndate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_kisti_aday`
--

CREATE TABLE `tbl_kisti_aday` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `kistiaday` int(11) NOT NULL,
  `loanType` varchar(255) NOT NULL,
  `kistiStutas` int(11) NOT NULL DEFAULT '0',
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_loan`
--

CREATE TABLE `tbl_loan` (
  `id` int(11) NOT NULL,
  `loanType` varchar(255) NOT NULL,
  `amount` int(11) NOT NULL,
  `loanNumbber` int(11) NOT NULL,
  `munafa` int(11) NOT NULL,
  `inTotal` int(11) NOT NULL,
  `startDate` varchar(255) NOT NULL,
  `endDate` varchar(255) NOT NULL,
  `kisti` int(11) NOT NULL,
  `totalKisti` int(11) NOT NULL,
  `loanBima` int(11) NOT NULL,
  `grantedName` varchar(255) NOT NULL,
  `grantedMobile` varchar(255) NOT NULL,
  `relation` varchar(255) NOT NULL,
  `customerId` int(11) NOT NULL,
  `loanstutas` int(11) NOT NULL DEFAULT '0',
  `date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_loan_bima_uttolon`
--

CREATE TABLE `tbl_loan_bima_uttolon` (
  `id` int(11) NOT NULL,
  `uttolon` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_nomoni`
--

CREATE TABLE `tbl_nomoni` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `nomoniName` varchar(255) NOT NULL,
  `fatherName` varchar(255) NOT NULL,
  `motherName` varchar(255) NOT NULL,
  `village` varchar(255) NOT NULL,
  `age` varchar(255) NOT NULL,
  `nomorelation` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_psaving_profit`
--

CREATE TABLE `tbl_psaving_profit` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `psprofit` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_rinbima`
--

CREATE TABLE `tbl_rinbima` (
  `id` int(11) NOT NULL,
  `rinBima` int(11) NOT NULL,
  `date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_sthayil_sonchoy_uttolon`
--

CREATE TABLE `tbl_sthayil_sonchoy_uttolon` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `sthuttolon` int(11) NOT NULL,
  `psprofit` int(11) NOT NULL,
  `sthdate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `tbl_title`
--

CREATE TABLE `tbl_title` (
  `id` int(11) NOT NULL,
  `title` text NOT NULL,
  `ftitle` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_title`
--

INSERT INTO `tbl_title` (`id`, `title`, `ftitle`) VALUES
(11, 'à¦à¦•à¦¤à¦¾ à¦¸à¦žà§à¦šà§Ÿ à¦“ à¦‹à¦£à¦¦à¦¾à¦¨ à¦¸à¦®à¦¬à¦¾à§Ÿ à¦¸à¦®à¦¿à¦¤à¦¿ à¦²à¦¿à¦®à¦¿à¦Ÿà§‡à¦¡à¥¤ à¦¸à§à¦¥à¦¾à¦ªà¦¿à¦¤à¦ƒ à§¦à§¬-à§¦à§©-à§¨à§¦à§§à§® à¦‡à¦‚à¥¤ à¦°à§‡à¦œà¦¿à¦ƒ à¦¨à¦‚- à§¦à§¨à§¨à¥¤ à¦ªà§à¦°à¦§à¦¾à¦¨ à¦•à¦¾à¦°à§à¦¯à¦¾à¦²à§Ÿà¦ƒ à¦¨à¦¿à¦•à¦°à¦¾à¦‡à¦² à¦¬à¦¾à¦œà¦¾à¦° à¦¹à¦¾à¦‡à¦¸à§à¦•à§à¦² à¦®à¦¾à¦°à§à¦•à§‡à¦Ÿ, à¦¨à¦¿à¦•à¦°à¦¾à¦‡à¦², à¦­à§‚à¦žà¦¾à¦ªà§à¦°, à¦Ÿà¦¾à¦™à§à¦—à¦¾à¦‡à¦²à¥¤', 'à¦à¦•à¦¤à¦¾ à¦¸à¦žà§à¦šà§Ÿ à¦“ à¦‹à¦£à¦¦à¦¾à¦¨ à¦¸à¦®à¦¬à¦¾à§Ÿ à¦¸à¦®à¦¿à¦¤à¦¿ à¦²à¦¿à¦ƒ Design by Abdul Alim (01742689979, alimbijoy@gmail.com)');

-- --------------------------------------------------------

--
-- Table structure for table `tbl_user`
--

CREATE TABLE `tbl_user` (
  `adminId` int(10) NOT NULL,
  `userName` varchar(255) NOT NULL,
  `adminName` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `adminPassword` varchar(255) NOT NULL,
  `mobile` varchar(2555) NOT NULL,
  `adminRole` int(10) NOT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_user`
--

INSERT INTO `tbl_user` (`adminId`, `userName`, `adminName`, `image`, `adminPassword`, `mobile`, `adminRole`, `date`) VALUES
(82, 'Admin', 'Abdul Alim', 'upload/22cbe06e34.jpg', '81dc9bdb52d04dc20036dbd8313ed055', '01742689979', 1, '2018-02-09 13:23:06');

-- --------------------------------------------------------

--
-- Table structure for table `tb_sthayi_sonchoy`
--

CREATE TABLE `tb_sthayi_sonchoy` (
  `id` int(11) NOT NULL,
  `customerId` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `aday` int(11) NOT NULL,
  `munafa` int(11) NOT NULL,
  `inTotal` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `btl_sthayi_sonchoy_aday`
--
ALTER TABLE `btl_sthayi_sonchoy_aday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `fornt_slider`
--
ALTER TABLE `fornt_slider`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_area`
--
ALTER TABLE `tbl_area`
  ADD PRIMARY KEY (`areaId`);

--
-- Indexes for table `tbl_balnce`
--
ALTER TABLE `tbl_balnce`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_balnce_uttolon`
--
ALTER TABLE `tbl_balnce_uttolon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bima`
--
ALTER TABLE `tbl_bima`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bima_aday`
--
ALTER TABLE `tbl_bima_aday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_bima_uttolon`
--
ALTER TABLE `tbl_bima_uttolon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_cost`
--
ALTER TABLE `tbl_cost`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  ADD PRIMARY KEY (`customerId`);

--
-- Indexes for table `tbl_dps_profit`
--
ALTER TABLE `tbl_dps_profit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_dps_totalprofit`
--
ALTER TABLE `tbl_dps_totalprofit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fixed_deposit`
--
ALTER TABLE `tbl_fixed_deposit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_fixed_deposit_lift`
--
ALTER TABLE `tbl_fixed_deposit_lift`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_general_saving_profit`
--
ALTER TABLE `tbl_general_saving_profit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_general_sonchoy_aday`
--
ALTER TABLE `tbl_general_sonchoy_aday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_general_sonchoy_uttolon`
--
ALTER TABLE `tbl_general_sonchoy_uttolon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_kisti_aday`
--
ALTER TABLE `tbl_kisti_aday`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_loan`
--
ALTER TABLE `tbl_loan`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_loan_bima_uttolon`
--
ALTER TABLE `tbl_loan_bima_uttolon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_nomoni`
--
ALTER TABLE `tbl_nomoni`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_psaving_profit`
--
ALTER TABLE `tbl_psaving_profit`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_rinbima`
--
ALTER TABLE `tbl_rinbima`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_sthayil_sonchoy_uttolon`
--
ALTER TABLE `tbl_sthayil_sonchoy_uttolon`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_title`
--
ALTER TABLE `tbl_title`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tbl_user`
--
ALTER TABLE `tbl_user`
  ADD PRIMARY KEY (`adminId`);

--
-- Indexes for table `tb_sthayi_sonchoy`
--
ALTER TABLE `tb_sthayi_sonchoy`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `btl_sthayi_sonchoy_aday`
--
ALTER TABLE `btl_sthayi_sonchoy_aday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `fornt_slider`
--
ALTER TABLE `fornt_slider`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `tbl_area`
--
ALTER TABLE `tbl_area`
  MODIFY `areaId` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tbl_balnce`
--
ALTER TABLE `tbl_balnce`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_balnce_uttolon`
--
ALTER TABLE `tbl_balnce_uttolon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bima`
--
ALTER TABLE `tbl_bima`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bima_aday`
--
ALTER TABLE `tbl_bima_aday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_bima_uttolon`
--
ALTER TABLE `tbl_bima_uttolon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_cost`
--
ALTER TABLE `tbl_cost`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_customer`
--
ALTER TABLE `tbl_customer`
  MODIFY `customerId` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_dps_profit`
--
ALTER TABLE `tbl_dps_profit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_dps_totalprofit`
--
ALTER TABLE `tbl_dps_totalprofit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_fixed_deposit`
--
ALTER TABLE `tbl_fixed_deposit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_fixed_deposit_lift`
--
ALTER TABLE `tbl_fixed_deposit_lift`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_general_saving_profit`
--
ALTER TABLE `tbl_general_saving_profit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_general_sonchoy_aday`
--
ALTER TABLE `tbl_general_sonchoy_aday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_general_sonchoy_uttolon`
--
ALTER TABLE `tbl_general_sonchoy_uttolon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_kisti_aday`
--
ALTER TABLE `tbl_kisti_aday`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_loan`
--
ALTER TABLE `tbl_loan`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_loan_bima_uttolon`
--
ALTER TABLE `tbl_loan_bima_uttolon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_nomoni`
--
ALTER TABLE `tbl_nomoni`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_psaving_profit`
--
ALTER TABLE `tbl_psaving_profit`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_rinbima`
--
ALTER TABLE `tbl_rinbima`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_sthayil_sonchoy_uttolon`
--
ALTER TABLE `tbl_sthayil_sonchoy_uttolon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `tbl_title`
--
ALTER TABLE `tbl_title`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `tbl_user`
--
ALTER TABLE `tbl_user`
  MODIFY `adminId` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `tb_sthayi_sonchoy`
--
ALTER TABLE `tb_sthayi_sonchoy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
