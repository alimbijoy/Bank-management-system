<?php
 $filepath = realpath(dirname(__FILE__));
 include_once($filepath.'/../lib/Database.php');
 include_once($filepath.'/../helpers/Format.php');
 	
  ?>

<?php

class Profit{
	
	private $db;
	private $fm;

	function __construct(){
		$this->db = new Database();
		$this->fm = new Format();
	}
        
        
        public function getSortDailyProfit(){
         
         $query ="SELECT sum(kistiaday), COUNT(*) FROM tbl_kisti_aday WHERE loanType='DailySortTime' AND kistiStutas='0'"; 
         $result = $this->db->select($query);
         return $result;   
            
            
        }
        
        public function getLongDailyProfit(){
         $query ="SELECT sum(kistiaday), COUNT(*) FROM tbl_kisti_aday WHERE loanType='DailyLongTime' AND kistiStutas='0'"; 
         $result = $this->db->select($query);
         return $result;    
        }

        

        public function getweeklyProfit(){
         
         $query ="SELECT sum(kistiaday), COUNT(*) FROM tbl_kisti_aday WHERE loanType='Weekly' AND kistiStutas='0'"; 
         $result = $this->db->select($query);
         return $result;    
            
            
        }
        
        
         public function getMonthlyProfit(){
         
         $query ="SELECT sum(kistiaday), COUNT(*) FROM tbl_kisti_aday WHERE loanType='Monthly' AND kistiStutas='0'"; 
         $result = $this->db->select($query);
         return $result;    
            
            
        }
        
    public function addbalnce($data){
    $balance   = $this->fm->validation($data['balance']);

   if(empty($balance)){
     $msg = "<span style='color:#ffff;'> Field mus not be empty!</span>";
      return $msg; 
   }else{
    $query ="INSERT INTO tbl_balnce (balance) VALUE('$balance')";
    
     $result = $this->db->insert($query);
         if($result){
             $msg = "<span style='color:#ffff;'> Add Balnce successfully.</span>";
             return $msg;       
         } else {
            $msg = "<span style='color:#ffff;'> Balnce Not Insert successfully.</span>";
             return $msg;
         }
       }   
    }
    
    
    
    public function addcost($data){
     
   $costName   = $this->fm->validation($data['costName']);
   $cost   = $this->fm->validation($data['cost']);

   if(empty($costName) || empty($cost)){
     $msg = "<span style='color:#ffff;'> Field mus not be empty!</span>";
      return $msg; 
   }else{
    $query ="INSERT INTO tbl_cost (costName, cost) VALUE('$costName', '$cost')";
    
     $result = $this->db->insert($query);
         if($result){
             $msg = "<span style='color:#ffff;'> Add Cost successfully.</span>";
             return $msg;       
         } else {
            $msg = "<span style='color:#ffff;'> Cost Not Insert successfully.</span>";
             return $msg;
         }
       }  
        
    }
    
    public function balnceuttolon($data){
   $uttolon= $this->fm->validation($data['uttolon']);
  
   if(empty($uttolon)){
     $msg = "<span style='color:#ffff;'> Field mus not be empty!</span>";
      return $msg; 
   }else{
    $query ="INSERT INTO tbl_balnce_uttolon (uttolon) VALUE('$uttolon')";
    
     $result = $this->db->insert($query);
         if($result){
             $msg = "<span style='color:#ffff;'> Balnace Uttolon successfully.</span>";
             return $msg;       
         } else {
            $msg = "<span style='color:#ffff;'> Balance Not Uttolon successfully.</span>";
             return $msg;
         }
       }    
    }
    
    public function rinbimaUttolon(){
     $query ="SELECT sum(uttolon), COUNT(*) FROM tbl_loan_bima_uttolon"; 
     $result = $this->db->select($query);
     return $result;       
    }
    
    public function totalcost(){
     $query ="SELECT sum(cost), COUNT(*) FROM tbl_cost"; 
     $result = $this->db->select($query);
     return $result;    
    }
    
    public function totalbalnce(){
     $query ="SELECT sum(balance), COUNT(*) FROM tbl_balnce"; 
     $result = $this->db->select($query);
     return $result;     
    }
    
    public function balnceuttolonn(){
     $query ="SELECT sum(uttolon), COUNT(*) FROM tbl_balnce_uttolon"; 
     $result = $this->db->select($query);
     return $result;    
    }
   
    
     public function balanceSearch($data){
      $balancestart = $data['balancestart'];
      $balanceEnd = $data['balanceEnd'];
        $query = "SELECT SUM(balance) FROM tbl_balnce WHERE date BETWEEN '{$balancestart}' AND '{$balanceEnd}'";     
        $result = $this->db->select($query);
        return $result;    
     }
     
     
      public function balanceuttolon($data){
      $balanceuttolonstart = $data['balanceuttolonstart'];
      $balanceuttolonEnd = $data['balanceuttolonEnd'];
        $query = "SELECT SUM(uttolon) FROM tbl_balnce_uttolon WHERE date BETWEEN '{$balanceuttolonstart}' AND '{$balanceuttolonEnd}'";     
        $result = $this->db->select($query);
        return $result;    
     }
     
     
      public function totalkistiaday($data){
      $kistyAdaytart = $data['kistyAdaytart'];
      $kistyAdayEnd = $data['kistyAdayEnd'];
        $query = "SELECT SUM(kistiaday) FROM tbl_kisti_aday WHERE date BETWEEN '{$kistyAdaytart}' AND '{$kistyAdayEnd}'";     
        $result = $this->db->select($query);
        return $result;    
     }
     
       public function gnsonchoyaday($data){
      $gnsonchoystart = $data['gnsonchoystart'];
      $gnsochoyend = $data['gnsochoyend'];
        $query = "SELECT SUM(gnsonchoyaday) FROM tbl_general_sonchoy_aday WHERE date BETWEEN '{$gnsonchoystart}' AND '{$gnsochoyend}'";     
        $result = $this->db->select($query);
        return $result;    
     }
     
     
      public function sthsonchoyaday($data){
      $sthsonchoystart = $data['sthsonchoystart'];
      $sthsonchoyend = $data['sthsonchoyend'];
        $query = "SELECT SUM(sthayiaday) FROM btl_sthayi_sonchoy_aday WHERE date BETWEEN '{$sthsonchoystart}' AND '{$sthsonchoyend}'";     
        $result = $this->db->select($query);
        return $result;    
     }
     
     
      public function rinbitoron($data){
      $rinbitornstart = $data['rinbitornstart'];
      $rinbitornend = $data['rinbitornend'];
        $query = "SELECT SUM(amount) FROM tbl_loan WHERE date BETWEEN '{$rinbitornstart}' AND '{$rinbitornend}'";     
        $result = $this->db->select($query);
        return $result;    
     }
     
     
      public function totalrinbimaaday($data){
      $rinbimaadaystart = $data['rinbimaadaystart'];
      $rinbimaadayend = $data['rinbimaadayend'];
        $query = "SELECT SUM(rinBima) FROM tbl_rinbima WHERE date BETWEEN '{$rinbimaadaystart}' AND '{$rinbimaadayend}'";     
        $result = $this->db->select($query);
        return $result;    
     }
     
     
      public function totalmunafaday($data){
      $munafastart = $data['munafastart'];
      $munafaend = $data['munafaend'];
        $query = "SELECT SUM(munafa) FROM tbl_loan WHERE date BETWEEN '{$munafastart}' AND '{$munafaend}'";     
        $result = $this->db->select($query);
        return $result;    
     }
  
     
     public function cost($data){
      $coststart = $data['coststart'];
      $costend = $data['costend'];
        $query = "SELECT SUM(cost) FROM tbl_cost WHERE date BETWEEN '{$coststart}' AND '{$costend}'";     
        $result = $this->db->select($query);
        return $result;    
     } 
     
      public function fixdeposittotal($data){
      $fixdeposit_start = $data['fixdeposit_start'];
      $fixdeposit_end = $data['fixdeposit_end'];
        $query = "SELECT SUM(amount) FROM tbl_fixed_deposit WHERE date BETWEEN '{$fixdeposit_start}' AND '{$fixdeposit_end}'";     
        $result = $this->db->select($query);
        return $result;    
     } 
     
      public function fixdepositprofitlif($data){
      $fixdepositpro_start = $data['fixdepositpro_start'];
      $fixdepositpro_end = $data['fixdepositpro_end'];
        $query = "SELECT SUM(Profit_amount) FROM tbl_fixed_deposit_lift WHERE date BETWEEN '{$fixdepositpro_start}' AND '{$fixdepositpro_end}'";     
        $result = $this->db->select($query);
        return $result;    
     }
     
     
     
     public function addRinbima($data){
       
   $rinBima  = $this->fm->validation($data['rinBima']);
   

   if(empty($rinBima)){
     $msg = "<span style='color:#ffff;'> Field mus not be empty!</span>";
     return $msg; 
   }else{
    $query ="INSERT INTO tbl_rinbima (rinBima) VALUE('$rinBima')";
    
     $result = $this->db->insert($query);
         if($result){
             $msg = "<span style='color:#ffff;'>Rin Bima Add successfully.</span>";
             return $msg;       
         } else {
            $msg = "<span style='color:#ffff;'> Rin Bima Not Add successfully.</span>";
             return $msg;
         }
       } 
   
     }
     
     public function deltitl($id){
         
     }

     
     
        
}       