



    
<?php
 $filepath = realpath(dirname(__FILE__));
 include_once($filepath.'/../lib/Database.php');
 include_once($filepath.'/../helpers/Format.php');
 	
  ?>

<?php

class FixedDeposit{
	
	private $db;
	private $fm;

	function __construct(){
		$this->db = new Database();
		$this->fm = new Format();
	} 
        
        public function addfixeddepositcustomer($data, $file){
            $amount                   = $this->fm->validation($data['amount']);
            $amountkothay             = $this->fm->validation($data['amountkothay']);
            $CustomerName             = $this->fm->validation($data['CustomerName']);           
            $cusfatherName            = $this->fm->validation($data['cusfatherName']);
            $cusmotherName            = $this->fm->validation($data['cusmotherName']);
            $cusvillage               = $this->fm->validation($data['cusvillage']);
            $cuspost                  = $this->fm->validation($data['cuspost']);
            $custhana                 = $this->fm->validation($data['custhana']);
            $cusDistrict              = $this->fm->validation($data['cusDistrict']);
            $cusgender                = $this->fm->validation($data['cusgender']);
            $cusnid                   = $this->fm->validation($data['cusnid']);
            $cusmobileNumber          = $this->fm->validation($data['cusmobileNumber']);
            $cusJoinDate              = $this->fm->validation($data['cusJoinDate']);
            $cusdateOfBirth           = $this->fm->validation($data['cusdateOfBirth']);
            $nomoniname               = $this->fm->validation($data['nomoniname']);
            $nomoniage                = $this->fm->validation($data['nomoniage']);
            $rilation                 = $this->fm->validation($data['rilation']);
           
          
            
            
           $permited  = array('jpg', 'jpeg', 'png', 'gif');
           
           $file_name = $file['customerPhoto']['name'];
           $file_size = $file['customerPhoto']['size'];
           $file_temp = $file['customerPhoto']['tmp_name'];
           
           $div = explode('.', $file_name);
           $file_ext = strtolower(end($div));
           $unique_image_name = substr(md5(time()), 0, 10).'.'.$file_ext;
           $uploaded_image = "upload/".$unique_image_name;
           
           
               
         if(empty($amount)|| empty($amountkothay)|| empty($CustomerName)|| empty($cusfatherName) || empty($cusmotherName)|| empty($cusvillage)||
           empty($cuspost) || empty($custhana) || empty($cusDistrict) || empty($cusgender) || empty($cusnid) || empty($cusmobileNumber) ||
           empty($cusJoinDate) || empty($cusdateOfBirth) || empty($nomoniname) || empty($nomoniage) || empty($rilation) || empty($uploaded_image)){			    	
           $msg = "<span style=color:red;>Field must not empty!</span>";
           return $msg;    
           }elseif(empty($file_name)) {
            $msg = "<span class='error'>Please select a image</span>";
            return $msg;
            }elseif ($file_size >1048567) {
              $msg = "<span class='error'>Image size should be less then 1 mb!</span>";
              return $msg;
            }elseif (in_array($file_ext, $permited) === false) {
              $msg = "<span class='error'>you can upload only:-".implode(', ', $permited)."</span>";
              return $msg;

            }else {          
              move_uploaded_file($file_temp, $uploaded_image);       
            $query = "INSERT INTO tbl_fixed_deposit
                     (amount, amountkothay, CustomerName, cusfatherName, cusmotherName, cusvillage, cuspost, custhana,
                      cusDistrict, cusgender, cusnid, cusmobileNumber, cusJoinDate, cusdateOfBirth, nomoniname, nomoniage, rilation, customerPhoto)
                      VALUES
                    ('$amount','$amountkothay', '$CustomerName','$cusfatherName', '$cusmotherName','$cusvillage','$custhana',
                    '$custhana', '$cusDistrict','$cusgender','$cusnid', '$cusmobileNumber', '$cusJoinDate', '$cusdateOfBirth',
                    '$nomoniname', '$nomoniage', '$rilation','$uploaded_image')";
            
                   $inserted_row = $this->db->insert($query);
                   if ($inserted_row) {
                    $msg = "<span style='color:#ffff'>Inserted Successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:red'>Not inserted </span>";
                    return $msg;
              }
     
        }  
        
    }
 
    public function getFixedDepositCustomer(){
     $query = "SELECT * FROM tbl_fixed_deposit";         
     $result = $this->db->select($query);     
     return $result;  
    }
    
    
    public function getfixedDepositbyId($depsitId){
     $query = "SELECT * FROM tbl_fixed_deposit WHERE id = '$depsitId'";         
     $result = $this->db->select($query);     
     return $result;   
    }
    
    public function editfixeddepositcustomer($data, $file, $depsitId){
            $amount                   = $this->fm->validation($data['amount']);
            $amountkothay             = $this->fm->validation($data['amountkothay']);
            $CustomerName             = $this->fm->validation($data['CustomerName']);           
            $cusfatherName            = $this->fm->validation($data['cusfatherName']);
            $cusmotherName            = $this->fm->validation($data['cusmotherName']);
            $cusvillage               = $this->fm->validation($data['cusvillage']);
            $cuspost                  = $this->fm->validation($data['cuspost']);
            $custhana                 = $this->fm->validation($data['custhana']);
            $cusDistrict              = $this->fm->validation($data['cusDistrict']);
            $cusgender                = $this->fm->validation($data['cusgender']);
            $cusnid                   = $this->fm->validation($data['cusnid']);
            $cusmobileNumber          = $this->fm->validation($data['cusmobileNumber']);
            $cusJoinDate              = $this->fm->validation($data['cusJoinDate']);
            $cusdateOfBirth           = $this->fm->validation($data['cusdateOfBirth']);
            $nomoniname               = $this->fm->validation($data['nomoniname']);
            $nomoniage                = $this->fm->validation($data['nomoniage']);
            $rilation                 = $this->fm->validation($data['rilation']);
           
          
            
            
           $permited  = array('jpg', 'jpeg', 'png', 'gif');
           
           $file_name = $file['customerPhoto']['name'];
           $file_size = $file['customerPhoto']['size'];
           $file_temp = $file['customerPhoto']['tmp_name'];
           
           $div = explode('.', $file_name);
           $file_ext = strtolower(end($div));
           $unique_image_name = substr(md5(time()), 0, 10).'.'.$file_ext;
           $uploaded_image = "upload/".$unique_image_name;
           
           
               
         if(empty($amount)|| empty($amountkothay)|| empty($CustomerName)|| empty($cusfatherName) || empty($cusmotherName)|| empty($cusvillage)||
           empty($cuspost) || empty($custhana) || empty($cusDistrict) || empty($cusgender) || empty($cusnid) || empty($cusmobileNumber) ||
           empty($cusJoinDate) || empty($cusdateOfBirth) || empty($nomoniname) || empty($nomoniage) || empty($rilation)){			    	
           $msg = "<span style=color:red;>Field must not empty!</span>";
           return $msg;    
           }elseif(empty($file_name)) {
            $msg = "<span class='error'>Please select a image</span>";
            return $msg;
            }elseif ($file_size >1048567) {
              $msg = "<span class='error'>Image size should be less then 1 mb!</span>";
              return $msg;
            }elseif (in_array($file_ext, $permited) === false) {
              $msg = "<span class='error'>you can upload only:-".implode(', ', $permited)."</span>";
              return $msg;

            }else { 
          //          extra
             $query = "select * from tbl_fixed_deposit where id='$depsitId'";
	        $getImg = $this->db->select($query);

	         if ($getImg) {
	         	while( $imgdata = $getImg->fetch_assoc()) { 
	         	$delimg = $imgdata['customerPhoto'];                      
                            unlink($delimg);  
	           }
	         }      
//          extra
          move_uploaded_file($file_temp, $uploaded_image);
          $query ="UPDATE tbl_fixed_deposit
                    SET
                    amount         = '$amount',
                    amountkothay   = '$amountkothay',
                   CustomerName    = '$CustomerName',
                    cusfatherName  = '$cusfatherName',
                    cusmotherName  = '$cusmotherName',
                    cusvillage     = '$cusvillage',
                    cuspost        = '$cuspost',
                    custhana       = '$custhana',
                    cusDistrict    = '$cusDistrict', 
                    cusgender      = '$cusgender',
                    cusnid         = '$cusnid', 
                    cusmobileNumber = '$cusmobileNumber', 
                    cusJoinDate     = '$cusJoinDate',
                     cusdateOfBirth = '$cusdateOfBirth',
                     nomoniname     = '$nomoniname',
                    nomoniage       = '$nomoniage',
                    rilation        = '$rilation',    
                    customerPhoto   = '$uploaded_image'      

                     WHERE id       = '$depsitId'"; 

   
              $updeted_row = $this->db->update($query);
              if ($updeted_row) {
               $msg = "<span style='color:#ffff;'> Customer updated successfully.</span>";
               return $msg;
                   }else{
                    $msg = "<span style='color:red'>Customer not updated </span>";
                    return $msg;
              }
     
        }    
    }
    
    public function depositById($depositid){
     $query = "SELECT * FROM tbl_fixed_deposit WHERE id = '$depositid'";         
     $result = $this->db->select($query);     
     return $result;      
    }
   
    
    public function fixedDepositProfitLift($data, $id){
       $Profit_amount            = $this->fm->validation($data['Profit_amount']);
       $amountkothay             = $this->fm->validation($data['amountkothay']);
       $lift_date                = $this->fm->validation($data['lift_date']);
       
       if(empty($Profit_amount) || empty($amountkothay) || empty($lift_date)){
           $msg = "Field must not be empty!";
       } else {
          $query = "INSERT INTO tbl_fixed_deposit_lift
                     (Profit_amount, amountkothay, lift_date, fix_deposit_cmr_id)
                      VALUES
                     ('$Profit_amount','$amountkothay', '$lift_date', '$id')";
            
                    $inserted_row = $this->db->insert($query);
                    if ($inserted_row) {
                    $msg = "<span style='color:#ffff'>Deposit lift Successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:red'>Deposit lift not lift Successfully</span>";
                    return $msg;
              } 
       }
       
    }
    
    public function getfixprofitlift($depositid){
      $query ="SELECT sum(Profit_amount), COUNT(*) FROM `tbl_fixed_deposit_lift` WHERE fix_deposit_cmr_id ='$depositid' "; 
      $result = $this->db->select($query);
      return $result;  
        
    }
    
    public function getfixdepositlift ($depositid){
        $query ="SELECT * FROM `tbl_fixed_deposit_lift` WHERE fix_deposit_cmr_id ='$depositid'"; 
         $result = $this->db->select($query);
         return $result;   
    }
    
    public function fixdepositdelte($id){
        $query ="delete fixdps.*, dpsprofit.*, fixeddepositlift.*
        from tbl_fixed_deposit as fixdps
        left join tbl_dps_profit as dpsprofit on dpsprofit.customerId = fixdps.id 
        left join tbl_fixed_deposit_lift as fixeddepositlift on fixeddepositlift.fix_deposit_cmr_id = fixdps.id 
        where fixdps.id='$id'"; 
        
        
        $result = $this->db->delete($query);
        return $result; 
    }
    
    public function fixed_deposit_customer(){
        $query ="SELECT id FROM `tbl_fixed_deposit`"; 
        $result = $this->db->select($query);
        return $result; 
    }
    
    public function totalfixed_deposit_amount(){
     $query ="SELECT sum(amount), COUNT(*) FROM tbl_fixed_deposit"; 
     $result = $this->db->select($query);
     return $result;    
    }
    
    
      public function totalfixed_deposit_profit(){
     $query ="SELECT sum(Profit_amount), COUNT(*) FROM tbl_fixed_deposit_lift"; 
     $result = $this->db->select($query);
     return $result;    
    }
    
    public function getFixedDepositDate(){
     $query ="SELECT * FROM tbl_fixed_deposit ORDER BY cusJoinDate ASC"; 
     $result = $this->db->select($query);
     return $result;     
    }
    
    public function getfixdpsprofit($depositid){
     $query ="SELECT * FROM tbl_dps_profit WHERE customerId='$depositid'"; 
     $result = $this->db->select($query);
     return $result;    
    }
    
    public function insertdpsprofit($depositid, $sum){
     $query = "INSERT INTO tbl_dps_profit
                     (customerId, dps_profit)
                      VALUES
                     ('$depositid','$sum')";
            
                    $inserted_row = $this->db->insert($query);
                    if ($inserted_row) {
                    $msg = "<span style='color:#ffff'>Insert lift successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:red'>Not inseret </span>";
                    return $msg;
              }    
           }
     
           public function updatedpsprofit($depositid, $sum){
             $query ="UPDATE tbl_dps_profit
                    SET
                    
                    dps_profit             = '$sum'                     
                    WHERE customerId       = '$depositid'"; 

   
              $updeted_row = $this->db->update($query);
              if ($updeted_row) {
               $msg = "<span style='color:#ffff;'> updated successfully.</span>";
               return $msg;
                   }else{
                    $msg = "<span style='color:red'>not updated </span>";
                    return $msg;
              }   
           }
           
           public function getdpsprofitt($id){
            $query ="SELECT * FROM tbl_dps_totalprofit WHERE customerId='$id'"; 
            $result = $this->db->select($query);
            return $result;     
           }
           
           public function getdpsprofittinsert( $id, $interest){
            $query = "INSERT INTO tbl_dps_totalprofit
                     (customerId, profit)
                      VALUES
                     ('$id','$interest')";
            
                    $inserted_row = $this->db->insert($query);
                    if ($inserted_row) {
                    $msg = "<span style='color:#E20D0D'>Insert lift successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:#E20D0D'>Not inseret </span>";
                    return $msg;
              }    
           }
           
           public function updatedpsprofitt( $id, $interest){
                  $query ="UPDATE tbl_dps_totalprofit
                    SET
                    
                    profit             = '$interest'                     
                    WHERE customerId       = '$id'"; 

   
              $updeted_row = $this->db->update($query);
              if ($updeted_row) {
               $msg = "<span style='color:#E20D0D;'> updated successfully.</span>";
               return $msg;
                   }else{
                    $msg = "<span style='color:#E20D0D'>not updated </span>";
                    return $msg;
              }   
           }
       
           
           public function getfixeddeposittotalprofit(){
           $query ="SELECT sum(dps_profit), COUNT(*) FROM tbl_dps_profit"; 
            $result = $this->db->select($query);
            return $result;      
           }
        
}

?>