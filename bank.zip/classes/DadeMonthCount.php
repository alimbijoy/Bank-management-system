<?php
 $filepath = realpath(dirname(__FILE__));
 include_once($filepath.'/../lib/Database.php');
 include_once($filepath.'/../helpers/Format.php');
 	
  ?>

<?php

class DadeMonthCount{
	
	private $db;
	private $fm;

    function __construct(){
        $this->db = new Database();
        $this->fm = new Format();
    }
        
    public function compoundintotal($duraion, $pmt, $paycount, $totalbalnce){
      
     if($duraion<=5){
    
      $r    = 0.07863;    
      $n    = 1/12*$paycount; 
      $m    =12;      
      $c    = $r/$m; 
      $fv   = ($pmt/$c)*(pow(1+$c, $m*$n)-1);    
     return $fv;    
           
       } else {
      $r    = 0.09652;    
      $n    = 1/12*$paycount; 
      $m    =12;      
      $c    = $r/$m; 
      $fv   = ($pmt/$c)*(pow(1+$c, $m*$n)-1);    
      return $fv;
           
       }    
   }
   
 
     public function compoundinterset($duraion, $pmt, $paycount, $bimaadayy){
      
     if($duraion<=5){
    
      $r    = 0.07863;    
      $n    = 1/12*$paycount; 
      $m    =12;      
      $c    = $r/$m; 
      $fv   = ($pmt/$c)*(pow(1+$c, $m*$n)-1);
      $interest = $fv-$bimaadayy;
     return $interest;    
           
      } else {
          
      $r    = 0.09652;    
      $n    = 1/12*$paycount; 
      $m    =12;      
      $c    = $r/$m; 
      $fv   = ($pmt/$c)*(pow(1+$c, $m*$n)-1);    
      
      return $fv; 
           
       }    
   }  
   
   
   
    public function compoundintotalpermentsaving($pmt, $paycount){
      
     
    
      $r    = 0.09652;    
      $n    = (1/12)*$paycount; 
      $m    = 12;      
      $c    = $r/$m; 
      $fv   = ($pmt/$c)*(pow(1+$c, $m*$n)-1);    
     return $fv;    

    }
   
     public function simpleinterset($pmt, $month, $r){        
     $t    = 1/12*$month; 
     $fv   = $pmt*(1+$r*$t);
     $interest = $fv-$pmt;
     return $interest;    
           
        
   }  
   

   public function monthcal($startingdate){
       $datetime1 = new DateTime($startingdate);
       $endingdate = date("H:i:s");
        $datetime2 = new DateTime($endingdate);
        $interval = $datetime1->diff($datetime2);
        $month = $interval->format('%m');
        return $month;
   }
   
   
   
   
       public function datecal($startingdate){
       $datetime1 = new DateTime($startingdate);
       $endingdate = date("H:i:s");
        $datetime2 = new DateTime($endingdate);
        $interval = $datetime1->diff($datetime2);
        $month = $interval->format('%d');
        return $month;
   }
   
   
   
   
   

      public function agecal($startingdate){
       $datetime1 = new DateTime($startingdate);
       $endingdate = date("H:i:s");
        $datetime2 = new DateTime($endingdate);
        $interval = $datetime1->diff($datetime2);
        $month = $interval->format('%y years %m months and %d days');
        return $month;
   }
   
   
   public function monthcount($date1){
        $begin = new DateTime($date1);
        $date2 = date("d M Y");
        $end   = new DateTime($date2);
        $end   = $end->modify( ' -1 month ' );

        $interval = DateInterval::createFromDateString( ' 1 month ' );
        $period   = new DatePeriod($begin, $interval, $end);

        $counter  = 0;
        foreach ($period as $dt){
          $counter++;  
      }
        return $counter;
   } 
        
        
                
         
 
}      