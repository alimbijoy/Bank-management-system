<?php
 $filepath = realpath(dirname(__FILE__));
 include_once($filepath.'/../lib/Database.php');
 include_once($filepath.'/../helpers/Format.php');
 	
  ?>

<?php

class Customer{
	
	private $db;
	private $fm;

	function __construct(){
		$this->db = new Database();
		$this->fm = new Format();
	}
        
        public function addCustomer($data, $file){
            $customerArea       = $this->fm->validation($data['customerArea']);
            $CustomerName        = $this->fm->validation($data['CustomerName']);
            $cusfatherName         = $this->fm->validation($data['cusfatherName']);           
            $cusmotherName          = $this->fm->validation($data['cusmotherName']);
            $cusvillage            = $this->fm->validation($data['cusvillage']);
            $cuspost               = $this->fm->validation($data['cuspost']);
            $custhana               = $this->fm->validation($data['custhana']);
            $cusDistrict            = $this->fm->validation($data['cusDistrict']);
            $cusgender            = $this->fm->validation($data['cusgender']);
            $cusnid            = $this->fm->validation($data['cusnid']);
            $cusmobileNumber        = $this->fm->validation($data['cusmobileNumber']);
            $cusJoinDate            = $this->fm->validation($data['cusJoinDate']);
            $cusdateOfBirth         = $this->fm->validation($data['cusdateOfBirth']);
          
            
            
           $permited  = array('jpg', 'jpeg', 'png', 'gif');
           
           $file_name = $file['customerPhoto']['name'];
           $file_size = $file['customerPhoto']['size'];
           $file_temp = $file['customerPhoto']['tmp_name'];
           
           $div = explode('.', $file_name);
           $file_ext = strtolower(end($div));
           $unique_image_name = substr(md5(time()), 0, 10).'.'.$file_ext;
           $uploaded_image = "upload/".$unique_image_name;
           
           
               
         if(empty($customerArea)|| empty($CustomerName)|| empty($cusfatherName)|| empty($cusmotherName) || empty($cusvillage)|| empty($cuspost)||
           empty($custhana) || empty($cusDistrict) || empty($cusgender) || empty($cusnid) || empty($cusmobileNumber) || empty($uploaded_image)){			    	
           $msg = "<span style=color:red;>Field must not empty!</span>";
           return $msg;    
           }elseif(empty($file_name)) {
            $msg = "<span class='error'>Please select a image</span>";
            return $msg;
            }elseif ($file_size >1048567) {
              $msg = "<span class='error'>Image size should be less then 1 mb!</span>";
              return $msg;
            }elseif (in_array($file_ext, $permited) === false) {
              $msg = "<span class='error'>you can upload only:-".implode(', ', $permited)."</span>";
              return $msg;

            }else {          
              move_uploaded_file($file_temp, $uploaded_image);       
            $query = "INSERT INTO tbl_customer
                     (customerArea, CustomerName, cusfatherName, cusmotherName, cusvillage, cuspost, custhana,
                      cusDistrict, cusgender, cusnid, cusmobileNumber, cusJoinDate, cusdateOfBirth, customerPhoto)
                      VALUES
                     ('$customerArea','$CustomerName', '$cusfatherName','$cusmotherName', '$cusvillage','$cuspost',
                    '$custhana', '$cusDistrict','$cusgender','$cusnid', '$cusmobileNumber', '$cusJoinDate', '$cusdateOfBirth',
                    '$uploaded_image')";
            
                   $inserted_row = $this->db->insert($query);
                   if ($inserted_row) {
                    $msg = "<span style='color:#ffff'>Customer inserted Successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:red'>Customer not inserted Successfully</span>";
                    return $msg;
              }
     
        }  
     
  }
  
  
  
  public function getAllCustomer(){
     $query = "SELECT * FROM tbl_customer";         
     $result = $this->db->select($query);     
     return $result;   
  }
  
   public function getAllCustomerForSearch(){
     $query = "SELECT * FROM tbl_customer WHERE cuslevel=0 ";         
     $result = $this->db->select($query);     
     return $result;   
  }
  
  public function getCustomerById($id){
   $query ="SELECT * FROM tbl_customer WHERE customerId='$id'"; 
            $result = $this->db->select($query);
            return $result;  
  }
  
  public function getcusimg($id){
      $query ="SELECT * FROM tbl_customer WHERE customerId='$id'"; 
        $result = $this->db->select($query);
        return $result;  
  }

  
  public function addNomoni($data, $file, $customerId){
      
        $nomoniName      = $this->fm->validation($data['nomoniName']);
        $fatherName      = $this->fm->validation($data['fatherName']);
        $motherName      = $this->fm->validation($data['motherName']);           
        $village         = $this->fm->validation($data['village']);
        $age             = $this->fm->validation($data['age']);
        $nomorelation        = $this->fm->validation($data['nomorelation']);
        
        
        $permited  = array('jpg', 'jpeg', 'png', 'gif');

        $file_name = $file['image']['name'];
        $file_size = $file['image']['size'];
        $file_temp = $file['image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_ext = strtolower(end($div));
        $unique_image_name = substr(md5(time()), 0, 10).'.'.$file_ext;
        $uploaded_image = "upload/".$unique_image_name;
        
         if(empty($nomoniName)|| empty($fatherName)|| empty($motherName)|| empty($village) || empty($age)|| empty($nomorelation) ||empty($uploaded_image)){			    	
           $msg = "<span style=color:red;>Field must not empty!</span>";
           return $msg;    
           }elseif(empty($file_name)) {
            $msg = "<span class='error'>Please select a image</span>";
            return $msg;
            }elseif ($file_size >1048567) {
              $msg = "<span class='error'>Image size should be less then 1 mb!</span>";
              return $msg;
            }elseif (in_array($file_ext, $permited) === false) {
              $msg = "<span class='error'>you can upload only:-".implode(', ', $permited)."</span>";
              return $msg;

            }else {          
              move_uploaded_file($file_temp, $uploaded_image);       
            $query = "INSERT INTO tbl_nomoni
                     (customerId, nomoniName, fatherName, motherName, village, age, nomorelation, image)
                      VALUES
                     ('$customerId','$nomoniName','$fatherName', '$motherName','$village', '$age','$nomorelation','$uploaded_image')";
             
            
                   $inserted_row = $this->db->insert($query);
                   if ($inserted_row) {
                    $msg = "<span style='color:#ffff;'>Nomoni inserted Successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:red'> Nomoni not inserted Successfully</span>";
                    return $msg;
              }
     
        }  
    
        
  }
  
  
  public function addArea($data){
   $areaName      = $this->fm->validation($data['areaName']);
   
   if(empty($areaName)){
     $msg = "<span style='color:#ffff;'>Fild Must Not be empty!</span>";
      return $msg;  
   } else {

      $query = "INSERT INTO tbl_area (areaName) VALUES ('$areaName')";

          $inserted_row = $this->db->insert($query);
          if ($inserted_row) {
           $msg = "<span style='color:#ffff;'>Area inserted Successfully</span>";
           return $msg;
          }else{
           $msg = "<span style='color:red'> Area not inserted Successfully</span>";
           return $msg;
     }
   
   }
  }
  
  
  public function getAllArea(){
    $query = "SELECT * FROM tbl_area";
     $result = $this->db->select($query);     
     return $result;     
  }
  
  public function getArea($id){
    $query = "SELECT * FROM tbl_area WHERE areaId='$id'";
     $result = $this->db->select($query);     
     return $result;    
  }
  
  public function editArea($data, $id){
    $areaName = $this->fm->validation($data['areaName']);
           $query ="UPDATE tbl_area SET areaName ='$areaName' WHERE areaId='$id'";

            $updeted_row = $this->db->update($query);
            if ($updeted_row) {
             $msg = "<span style='color:#ffff;'>Area Updated Successfully.</span>";
             return $msg;
             
            }else {
             $msg = "<span class='error'>Area Not Updated !</span>";
             return $msg;
            }
  }
  
  public function delUser($id){
    $query = "DELETE FROM tbl_area WHERE areaId = '$id'";
      $result = $this->db->delete($query);
      return $result;  
  }
  
  public function getNomoniById($customerId){
     $query = "SELECT * FROM tbl_nomoni WHERE customerId='$customerId'";
     $result = $this->db->select($query);     
     return $result;  
  }
  
  public function delNomoni($id){
     $query = "DELETE FROM tbl_nomoni WHERE customerId='$id'";
     $result = $this->db->delete($query);
     return $result;   
  }
  
  public function updateNomoni($data, $file, $customerId){
      
       $nomoniName      = $this->fm->validation($data['nomoniName']);
       $fatherName      = $this->fm->validation($data['fatherName']);
       $motherName      = $this->fm->validation($data['motherName']);
       $village         = $this->fm->validation($data['village']);
       $age             = $this->fm->validation($data['age']);
       $nomorelation   = $this->fm->validation($data['nomorelation']);


       
        $permited  = array('jpg', 'jpeg', 'png', 'gif');
        
        $file_name = $file['image']['name'];
        $file_size = $file['image']['size'];
        $file_temp = $file['image']['tmp_name'];

        $div = explode('.', $file_name);
        $file_ext = strtolower(end($div));
        $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
        $uploaded_image = "upload/".$unique_image;
        
      
        

        
        

        if ($nomoniName == "" || $fatherName == "" || $motherName == "" || $village == "" || $age == "" || $nomorelation == "" ) {
             $msg = "<span class='error'>Field must not be empty!</span>";
             return $msg;

        }else{


     if (!empty($file_name)) {
                        
            if ($file_size >1048567) {
             $msg = "<span class='error'>Image Size should be less then 1MB!</span>";
             return $msg;
             
            } elseif (in_array($file_ext, $permited) === false) {
             $msg =  "<span class='error'>You can upload only:-".implode(', ', $permited)."</span>";
             return $msg;
            } else{
//          extra
             $query = "select * from tbl_nomoni where customerId='$customerId'";
	        $getImg = $this->db->select($query);

	         if ($getImg) {
	         	while( $imgdata = $getImg->fetch_assoc()) { 
	         	$delimg = $imgdata['image'];
                        
                            unlink($delimg);  
                        
                      

	           }
	         }      
//          extra
          move_uploaded_file($file_temp, $uploaded_image);
          $query ="UPDATE tbl_nomoni
                    SET
                    nomoniName   = '$nomoniName',
                    fatherName   = '$fatherName',
                   motherName    = '$motherName',
                    village      = '$village',
                    age          = '$age',
                    nomorelation     = '$nomorelation',
                    image        ='$uploaded_image'
                     WHERE customerId = '$customerId' "; 

   
              $updeted_row = $this->db->update($query);
              if ($updeted_row) {
               $msg = "<span style='color:#ffff;'>Nomoni Updated Successfully.</span>";
               return $msg;
             
            }else {
             $msg = "<span class='error'>Nomoni Not Updated !</span>";
             return $msg;
            }
        }

     }
 
   }

  }
  
  
  public function updateCustomer($data, $file, $customerId){
      
        $customerArea          = $this->fm->validation($data['customerArea']);
        $CustomerName          = $this->fm->validation($data['CustomerName']);
        $cusfatherName         = $this->fm->validation($data['cusfatherName']);           
        $cusmotherName         = $this->fm->validation($data['cusmotherName']);
        $cusvillage            = $this->fm->validation($data['cusvillage']);
        $cuspost               = $this->fm->validation($data['cuspost']);
        $custhana              = $this->fm->validation($data['custhana']);
        $cusDistrict           = $this->fm->validation($data['cusDistrict']);
        $cusgender             = $this->fm->validation($data['cusgender']);
        $cusnid                = $this->fm->validation($data['cusnid']);
        $cusmobileNumber       = $this->fm->validation($data['cusmobileNumber']);
        $cusJoinDate           = $this->fm->validation($data['cusJoinDate']);
        $cusdateOfBirth        = $this->fm->validation($data['cusdateOfBirth']);
        
        
        
       $permited  = array('jpg', 'jpeg', 'png', 'gif');
        
        $file_name = $file['customerPhoto']['name'];
        $file_size = $file['customerPhoto']['size'];
        $file_temp = $file['customerPhoto']['tmp_name'];

        $div = explode('.', $file_name);
        $file_ext = strtolower(end($div));
        $unique_image = substr(md5(time()), 0, 10).'.'.$file_ext;
        $uploaded_image = "upload/".$unique_image;
        
      
        
        
        
        
        
        
        if ($customerArea == "" || $CustomerName == "" || $cusfatherName == "" || $cusvillage == "" ||
            $cuspost == "" || $custhana == "" || $cusDistrict == "" || $cusgender == "" || $cusnid == ""
            || $cusmobileNumber == "" || $cusJoinDate == "" || $cusdateOfBirth == "" ) {
             $msg = "<span style='color:#ffff;'>Field must not be empty!</span>";
             return $msg;

        }else{


     if (!empty($file_name)) {
                        
            if ($file_size >1048567) {
             $msg = "<span style='color:#ffff;'>Image Size should be less then 1MB!</span>";
             return $msg;
             
            } elseif (in_array($file_ext, $permited) === false) {
             $msg =  "<span style='color:#ffff;'>You can upload only:-".implode(', ', $permited)."</span>";
             return $msg;
            } else{
//          extra
             $query = "select * from tbl_customer where customerId='$customerId'";
	        $getImg = $this->db->select($query);

	         if ($getImg) {
	         	while( $imgdata = $getImg->fetch_assoc()) { 
	         	$delimg = $imgdata['customerPhoto'];
                        
                            unlink($delimg);  
                        
                      

	           }
	         }      
//          extra
          move_uploaded_file($file_temp, $uploaded_image);
          $query ="UPDATE tbl_customer
                    SET
                    customerArea   = '$customerArea',
                    CustomerName   = '$CustomerName',
                   cusfatherName   = '$cusfatherName',
                    cusmotherName  = '$cusmotherName',
                    cusvillage     = '$cusvillage',
                    cuspost        = '$cuspost',
                    custhana       = '$custhana',
                    cusDistrict    = '$cusDistrict',
                    cusgender      = '$cusgender', 
                    cusnid         = '$cusnid',
                    cusmobileNumber = '$cusmobileNumber', 
                    cusJoinDate    = '$cusJoinDate', 
                    cusdateOfBirth = '$cusdateOfBirth',
                    customerPhoto  = '$uploaded_image'      

                     WHERE customerId = '$customerId'"; 

   
              $updeted_row = $this->db->update($query);
              if ($updeted_row) {
               $msg = "<span style='color:#ffff;'> Customer Updated Successfully.</span>";
               return $msg;
             
            }else {
             $msg = "<span style='color:#ffff;'> Customer Not Updated !</span>";
             return $msg;
            }
        }

     }
 
   }
 
  }
        
 
  public function addNomonichoy($data, $customerId){
     $duration      = $this->fm->validation($data['duration']);
     $aday          = $this->fm->validation($data['aday']);
     $munafa        = $this->fm->validation($data['munafa']);
     $inTotal       = $this->fm->validation($data['inTotal']);
     
     if(empty($duration )|| empty($aday)|| empty($munafa) || empty($inTotal)){
        $msg = "<span style='color:#ffff;'> Field Must not be empty!</span>";
         return $msg;
     } else {
         $query ="INSERT INTO tb_sthayi_sonchoy(customerId, duration, aday, munafa, inTotal) VALUE('$customerId', '$duration', '$aday', '$munafa', '$inTotal')";
         $result = $this->db->insert($query);
         if($result){
             $msg = "<span style='color:#ffff;'> Insert successfully.</span>";
             return $msg;       
         } else {
            $msg = "<span style='color:#ffff;'> Not insert successfully.</span>";
             return $msg;
         }
     }
  }
  
  
  public function gnSonchoyUttolon($data, $customerId){
      $gnuttolon   = $this->fm->validation($data['gnuttolon']);
      $gnprofit   = $this->fm->validation($data['gnprofit']);           
     
      $query = "INSERT INTO tbl_general_sonchoy_uttolon
                     (customerId, gnuttolon, gnprofit)
                      VALUES
                     ('$customerId','$gnuttolon','$gnprofit')";
            
                   $inserted_row = $this->db->insert($query);
                   if ($inserted_row) {
                    $msg = "<span style='color:#ffff'>Lift Successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:red'>Not lift !</span>";
                    return $msg;
              } 
      
  }
  
  
    public function sthSonchoyUttolon($data, $customerId){
      $sthuttolon   = $this->fm->validation($data['sthuttolon']);
      $psprofit   = $this->fm->validation($data['psprofit']);
      
     
          $query = "INSERT INTO tbl_sthayil_sonchoy_uttolon
                     (customerId, sthuttolon, psprofit)
                      VALUES
                     ('$customerId','$sthuttolon', '$psprofit')";
            
                   $inserted_row = $this->db->insert($query);
                   if ($inserted_row) {
                    $msg = "<span style='color:#ffff'>Uttolon Successfully</span>";
                    return $msg;
                   }else{
                    $msg = "<span style='color:red'>Not Uttolon !</span>";
                    return $msg;
              } 
      
  }
  
  
  
 
  
  
  
  
  
  public function rinBimaUttolon($data){
   $uttolon   = $this->fm->validation($data['uttolon']);

   if(empty($uttolon)){
    $msg = "<span style='color:#ffff;'> Field mus not be empty!</span>";
     return $msg; 
   }else{
    $query ="INSERT INTO tbl_loan_bima_uttolon (uttolon) VALUE($uttolon)";
    
     $result = $this->db->insert($query);
         if($result){
             $msg = "<span style='color:#ffff;'> Rin Bima Uttolon successfully.</span>";
             return $msg;       
         } else {
            $msg = "<span style='color:#ffff;'> Rin Bima Not Uttolon successfully.</span>";
             return $msg;
         }
   } 
   
  }
  
  public function addBima($data, $customerId){
     $bimaDuration      = $this->fm->validation($data['bimaDuration']);
     $datee              = $this->fm->validation($data['datee']);
     $bimaAday          = $this->fm->validation($data['bimaAday']);
     $bimaMunafa        = $this->fm->validation($data['bimaMunafa']);
     $bimaInTotal       = $this->fm->validation($data['bimaInTotal']);
     
     if(empty($bimaDuration )|| empty($datee) || empty($bimaAday)|| empty($bimaMunafa) || empty($bimaInTotal)){
        $msg = "<span style='color:#ffff;'> Field Must not be empty!</span>";
         return $msg;
     } else {
         $query ="INSERT INTO tbl_bima(customerId, bimaDuration, datee, bimaAday, bimaMunafa, bimaInTotal) VALUE('$customerId', '$bimaDuration', '$datee', '$bimaAday', '$bimaMunafa', '$bimaInTotal')";
         $result = $this->db->insert($query);
         if($result){
             $msg = "<span style='color:#ffff;'> Bima Insert successfully.</span>";
             return $msg;       
         } else {
            $msg = "<span style='color:#ffff;'>Bima Not insert successfully.</span>";
             return $msg;
         }
     }  
  }
  
  
  
  public function bimaUttolon($data, $customerId){
     $bimaUttolon      = $this->fm->validation($data['bimaUttolon']);
     $profit_lift      = $this->fm->validation($data['profit_lift']);
     
     
   
         $query ="INSERT INTO tbl_bima_uttolon(customerId, bimaUttolon, profit_lift) VALUE('$customerId', '$bimaUttolon', '$profit_lift')";
         $result = $this->db->insert($query);
         if($result){
             $msg = "<span style='color:#ffff;'> Bima Uttolon successfully.</span>";
             return $msg;       
         } else {
            $msg = "<span style='color:#ffff;'>Bima Not Uttolon successfully.</span>";
             return $msg;
         }
      
  }
  
  
  public function deleteloanById($delid){
       $query ="delete loann.*, loanaday.*           
            from tbl_loan as loann 
            left join tbl_kisti_aday as loanaday on loanaday.customerId = loann.customerId            
            where loann.customerId = '$delid'";    
           $result = $this->db->delete($query);
           return $result;
  }
  
  public function deletedps($dpsid){
    $query ="delete dps.*, dpspay.*, dpslift.*, totalprofit.*
            from tbl_bima as dps
            left join tbl_bima_aday as dpspay on dpspay.customerId = dps.customerId 
            left join tbl_bima_uttolon as dpslift on dpslift.customerId = dps.customerId 
            left join tbl_dps_totalprofit as totalprofit on totalprofit.customerId = dps.customerId 
            where dps.customerId='$dpsid'";    
    $result = $this->db->delete($query);
    return $result;  
  }
  
  public function getgnstotalprofit(){
   $query ="SELECT sum(profit), COUNT(*) FROM `tbl_general_saving_profit`";
    $result = $this->db->select($query);
    return $result;    
  }
  
  public function getgnstotalprofitlift(){
   $query ="SELECT sum(gnprofit), COUNT(*) FROM `tbl_general_sonchoy_uttolon`";
    $result = $this->db->select($query);
    return $result;    
  }
  
  
  public function getpstotalprofit(){
  $query ="SELECT sum(psprofit), COUNT(*) FROM `tbl_psaving_profit`";
    $result = $this->db->select($query);
    return $result;     
  }
  
  public function getpstotalprofitlift(){
   $query ="SELECT sum(psprofit), COUNT(*) FROM `tbl_sthayil_sonchoy_uttolon`";
    $result = $this->db->select($query);
    return $result;      
  }
  
    public function getDpsTotalProfit(){
   $query ="SELECT sum(profit), COUNT(*) FROM `tbl_dps_totalprofit`";
    $result = $this->db->select($query);
    return $result;      
  }
  
  public function getProfitLiftById($id){
   $query ="SELECT sum(profit_lift), COUNT(*) FROM `tbl_bima_uttolon` where customerId='$id'";
    $result = $this->db->select($query);
    return $result;    
  }
  
  public function getDpsBalanceLiftById($id){
   $query ="SELECT sum(bimaUttolon), COUNT(*) FROM `tbl_bima_uttolon` where customerId='$id'";
    $result = $this->db->select($query);
    return $result;     
  }
  
  public function getDpsLiftProfit(){
   $query ="SELECT sum(profit_lift), COUNT(*) FROM `tbl_bima_uttolon`";
    $result = $this->db->select($query);
    return $result;      
  }
       
  
        
}        